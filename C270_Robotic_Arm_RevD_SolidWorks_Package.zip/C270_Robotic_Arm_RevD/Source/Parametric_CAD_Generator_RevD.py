"""Generate Revision D of the SolidWorks-ready C270 pan/tilt arm.

Units are millimetres.  The STEP files are the preferred SolidWorks imports;
STL files are supplied for printing and quick visual checks.  Revision D adds
a broad pan-servo stability base with a full-depth, edge-open cable channel.
"""

from __future__ import annotations

import math
from pathlib import Path

import cadquery as cq
from cadquery import exporters


OUT = Path(r"C:\Users\zongs\Documents\Codex\2026-08-20\can-y\outputs\C270_Robotic_Arm_RevD")
WORK = Path(r"C:\Users\zongs\Documents\Codex\2026-08-20\can-y\work")
OUT.mkdir(parents=True, exist_ok=True)
PRINT_DIR = OUT / "Printable_Parts"
REF_DIR = OUT / "Reference_Models"
ASM_DIR = OUT / "Assemblies"
DOC_DIR = OUT / "Documentation"
RENDER_DIR = OUT / "Renders"
for directory in (PRINT_DIR, REF_DIR, ASM_DIR, DOC_DIR, RENDER_DIR):
    directory.mkdir(parents=True, exist_ok=True)

# Core arm dimensions from the user's sketch.
ARM_CENTER_SPACING = 80.0
ARM_CENTERLINE_RADIUS = 50.0
ARM_WIDTH = 14.0
ARM_THICKNESS = 6.0
BOSS_DIAMETER = 28.0
PAN_PAD_DIAMETER = 40.0
PAN_PAD_THICKNESS = 4.0

# Common SG90 envelope plus print clearance.  The open flange slots tolerate
# small clone-to-clone differences and let the supplied servo model be checked
# after STEP import.
SERVO_BODY_X = 22.8
SERVO_BODY_Y = 12.2
SERVO_CLEARANCE = 0.8
TILT_AXIS_Z = 94.0

# Logitech C270 bounding data supplied by the user.
C270_WIDTH = 72.91
C270_HEIGHT = 31.91
C270_DEPTH_WITH_CLIP = 66.64
C270_MASS_G = 75.0

# Revision D pan-servo stability base.  The 140 mm circular footprint is
# uniform in every pan direction and fits common 220 x 220 mm FDM beds.
BASE_DIAMETER = 140.0
BASE_THICKNESS = 6.0
BASE_BOTTOM_Z = -27.0
BASE_TOP_Z = BASE_BOTTOM_Z + BASE_THICKNESS
BASE_MOUNT_RADIUS = 50.0
CABLE_CHANNEL_WIDTH = 22.0


def box_at(x1: float, x2: float, y1: float, y2: float, z1: float, z2: float) -> cq.Workplane:
    """Axis-aligned box from minima/maxima."""
    return (
        cq.Workplane("XY")
        .box(x2 - x1, y2 - y1, z2 - z1, centered=(True, True, False))
        .translate(((x1 + x2) / 2.0, (y1 + y2) / 2.0, z1))
    )


def cyl_y(radius: float, y1: float, y2: float, x: float, z: float) -> cq.Workplane:
    solid = cq.Solid.makeCylinder(
        radius,
        y2 - y1,
        cq.Vector(x, y1, z),
        cq.Vector(0, 1, 0),
    )
    return cq.Workplane(obj=solid)


def cyl_z(radius: float, z1: float, z2: float, x: float = 0.0, y: float = 0.0) -> cq.Workplane:
    solid = cq.Solid.makeCylinder(
        radius,
        z2 - z1,
        cq.Vector(x, y, z1),
        cq.Vector(0, 0, 1),
    )
    return cq.Workplane(obj=solid)


def arm_ribbon() -> cq.Workplane:
    """Curved 14 mm ribbon using exact analytic arcs, not segmented lines."""
    bottom_z = 14.0
    arc_cx = 30.0
    arc_cz = bottom_z + ARM_CENTER_SPACING / 2.0
    outer_r = ARM_CENTERLINE_RADIUS + ARM_WIDTH / 2.0
    inner_r = ARM_CENTERLINE_RADIUS - ARM_WIDTH / 2.0
    start_deg = math.degrees(math.atan2(bottom_z - arc_cz, -arc_cx))
    end_deg = start_deg - math.degrees(
        2.0 * math.asin(ARM_CENTER_SPACING / (2.0 * ARM_CENTERLINE_RADIUS))
    )

    mid_deg = (start_deg + end_deg) / 2.0

    def point(radius: float, angle_deg: float) -> tuple[float, float]:
        angle = math.radians(angle_deg)
        return (arc_cx + radius * math.cos(angle), arc_cz + radius * math.sin(angle))

    outer_start = point(outer_r, start_deg)
    outer_mid = point(outer_r, mid_deg)
    outer_end = point(outer_r, end_deg)
    inner_end = point(inner_r, end_deg)
    inner_mid = point(inner_r, mid_deg)
    inner_start = point(inner_r, start_deg)

    ribbon = (
        cq.Workplane("XZ")
        .moveTo(*outer_start)
        .threePointArc(outer_mid, outer_end)
        .lineTo(*inner_end)
        .threePointArc(inner_mid, inner_start)
        .close()
        .extrude(ARM_THICKNESS / 2.0, both=True)
    )
    bottom_boss = (
        cq.Workplane("XZ")
        .center(0, bottom_z)
        .circle(BOSS_DIAMETER / 2.0)
        .extrude(ARM_THICKNESS / 2.0, both=True)
    )
    top_boss = (
        cq.Workplane("XZ")
        .center(0, bottom_z + ARM_CENTER_SPACING)
        .circle(BOSS_DIAMETER / 2.0)
        .extrude(ARM_THICKNESS / 2.0, both=True)
    )
    smooth_arm = ribbon.union(bottom_boss).union(top_boss).clean()
    # Round the two broad-profile edges to remove the hard ridge and improve grip/appearance.
    try:
        smooth_arm = smooth_arm.edges("|Y").fillet(1.0)
    except Exception:
        # The exact arcs remain smooth even if a kernel build rejects a cosmetic fillet.
        pass
    return smooth_arm


def make_arm_and_holder() -> cq.Workplane:
    # Horizontal pan-horn pad: pan axis is Z; tilt axis is Y, exactly 90 degrees apart.
    # The pad starts at Z=4 mm, leaving room below it for the SG90 horn.
    pad = (
        cq.Workplane("XY")
        .circle(PAN_PAD_DIAMETER / 2.0)
        .extrude(PAN_PAD_THICKNESS)
        .translate((0, 0, 4.0))
    )
    pad = pad.edges("%CIRCLE").fillet(1.0)
    pad = pad.cut(cyl_z(1.6, 3.5, 8.5))
    for x, y in ((7, 0), (-7, 0), (0, 7), (0, -7)):
        pad = pad.cut(cyl_z(1.0, 3.5, 8.5, x, y))

    # Trim the vertical profile at the pan-pad interface; it no longer protrudes into the horn.
    upright = arm_ribbon().intersect(box_at(-100, 100, -100, 100, 7.5, 200.0))
    arm = pad.union(upright)

    # Compact sideways SG90 cage.  Servo slides in from +Y; output shaft points +Y.
    holder = box_at(-17.0, 17.0, 2.5, 6.0, 84.0, 104.0)  # back
    holder = holder.union(box_at(-15.5, 15.5, 2.5, 24.0, 84.0, 87.0))  # lower rail
    holder = holder.union(box_at(-15.5, -12.2, 2.5, 24.0, 84.0, 104.0))
    holder = holder.union(box_at(12.2, 15.5, 2.5, 24.0, 84.0, 104.0))
    holder = holder.union(box_at(-15.5, 15.5, 2.5, 24.0, 101.0, 104.0))

    # Openings for the standard SG90 mounting ears near the output end.
    holder = holder.cut(box_at(-17.0, -12.0, 18.0, 24.5, 87.0, 101.0))
    holder = holder.cut(box_at(12.0, 17.0, 18.0, 24.5, 87.0, 101.0))

    # Servo-wire escape on the lower-right rear side.
    holder = holder.cut(box_at(2.0, 17.5, 1.8, 7.0, 84.0, 91.0))

    # Four cap pilot holes, axis Y.  They accept M2 self-tapping screws.
    for x in (-13.85, 13.85):
        for z in (87.8, 100.2):
            holder = holder.cut(cyl_y(1.0, 1.5, 24.5, x, z))

    return arm.union(holder).clean()


def make_servo_cap() -> cq.Workplane:
    cap = box_at(-15.5, 15.5, 24.0, 27.0, 82.0, 106.0)
    # Round output/horn clearance leaves the central servo face visible.
    cap = cap.cut(cyl_y(10.5, 23.5, 27.5, 0.0, TILT_AXIS_Z))
    for x in (-13.85, 13.85):
        for z in (87.8, 100.2):
            cap = cap.cut(cyl_y(1.15, 23.5, 27.5, x, z))
    return cap.clean()


def make_camera_clip_cradle() -> cq.Workplane:
    # A 5 mm "monitor blade" for the C270's fixed clip.  The generous width
    # prevents side-to-side walk; optional zip ties pass through the two slots.
    plate = box_at(-38.0, 38.0, 4.0, 9.0, -30.0, 6.0)
    plate = plate.edges("|Y").fillet(2.0)
    horn_boss = cyl_y(12.5, 0.0, 4.5, 0.0, 0.0)
    cradle = plate.union(horn_boss)

    # Rear/right USB cable escape notch and two retaining-strap slots.
    cradle = cradle.cut(box_at(25.0, 39.0, 3.5, 9.5, -6.0, 7.0))
    for x in (-27.0, 27.0):
        cradle = cradle.cut(box_at(x - 2.0, x + 2.0, -0.5, 10.0, -22.0, -7.0))

    # Horn attachment pattern: center clearance and four adaptable pilot holes.
    cradle = cradle.cut(cyl_y(1.6, -0.5, 9.5, 0.0, 0.0))
    for x, z in ((7, 0), (-7, 0), (0, 7), (0, -7)):
        cradle = cradle.cut(cyl_y(1.0, -0.5, 9.5, x, z))

    # Low end stops preserve the open top edge used by the fixed webcam clip.
    cradle = cradle.union(box_at(-40.0, -37.8, 3.5, 12.0, -30.0, 0.0))
    cradle = cradle.union(box_at(37.8, 40.0, 3.5, 12.0, -30.0, 0.0))
    return cradle.clean()


def make_pan_servo_stability_base() -> cq.Workplane:
    """Wide, low base that supports and fastens the upright pan SG90.

    The SG90 reference body rests on the plate at Z=-21 mm.  Two side towers
    sit clear of the body and support its mounting ears.  Pilot holes accept
    common M2 servo screws, while the outer M4 holes can fasten the base to a
    board or accept rubber-foot hardware.  Strap slots provide a clone-tolerant
    fallback when ear-hole spacing differs.
    """
    base = (
        cq.Workplane("XY")
        .circle(BASE_DIAMETER / 2.0)
        .extrude(BASE_THICKNESS)
        .translate((0, 0, BASE_BOTTOM_Z))
    )
    try:
        base = base.edges("%CIRCLE").fillet(1.8)
    except Exception:
        pass

    # Upright supports and ledges for the two horizontal SG90 mounting ears.
    left_tower = box_at(-18.5, -12.2, -8.5, 8.5, BASE_TOP_Z, -8.4)
    right_tower = box_at(12.2, 18.5, -8.5, 8.5, BASE_TOP_Z, -8.4)
    left_ledge = box_at(-19.0, -11.8, -10.5, 10.5, -10.6, -8.4)
    right_ledge = box_at(11.8, 19.0, -10.5, 10.5, -10.6, -8.4)
    base = base.union(left_tower).union(right_tower).union(left_ledge).union(right_ledge)

    # M2 self-tapping pilot holes beneath the standard SG90 ear locations.
    for x in (-14.2, 14.2):
        base = base.cut(cyl_z(0.95, -15.0, -7.8, x, 0.0))

    # Two through-slots let a narrow zip tie retain unusually shaped SG90 clones.
    base = base.cut(box_at(-24.5, -21.5, -8.0, 8.0, BASE_BOTTOM_Z - 0.5, BASE_TOP_Z + 0.5))
    base = base.cut(box_at(21.5, 24.5, -8.0, 8.0, BASE_BOTTOM_Z - 0.5, BASE_TOP_Z + 0.5))

    # Full-depth rear cable channel.  It begins beneath the upright pan servo
    # and opens through the rear rim, so the tilt-servo lead and C270 USB cable
    # can be laid in from the edge instead of being threaded through a small
    # hole.  The SG90 mounting ears remain supported by the two side ledges.
    half_channel = CABLE_CHANNEL_WIDTH / 2.0
    base = base.cut(
        box_at(
            -half_channel,
            half_channel,
            -71.0,
            7.0,
            BASE_BOTTOM_Z - 0.5,
            BASE_TOP_Z + 0.5,
        )
    )

    # Four M4-class table/board mounting holes with shallow top counterbores.
    offset = BASE_MOUNT_RADIUS / math.sqrt(2.0)
    for x in (-offset, offset):
        for y in (-offset, offset):
            base = base.cut(cyl_z(2.2, BASE_BOTTOM_Z - 0.5, BASE_TOP_Z + 0.5, x, y))
            base = base.cut(cyl_z(4.2, -23.2, BASE_TOP_Z + 0.5, x, y))

    return base.clean()


def make_sg90_reference() -> tuple[cq.Workplane, cq.Workplane]:
    """A dimensionally representative SG90 body and horn for assembly visualization."""
    # Upright reference: output axis is +Z at the origin; body extends downward.
    body = box_at(-11.4, 11.4, -6.1, 6.1, -21.0, -4.0)
    body = body.union(box_at(-16.2, 16.2, -6.1, 6.1, -8.0, -5.8))
    body = body.union(cyl_z(6.0, -4.0, -0.7, 0.0, 0.0))
    body = body.union(cyl_z(4.0, -4.0, -0.7, 6.0, 0.0))
    body = body.union(cyl_z(2.35, -0.7, 2.0, 0.0, 0.0))
    for x in (-14.0, 14.0):
        body = body.cut(cyl_z(1.1, -8.5, -5.3, x, 0.0))
    try:
        body = body.edges("|Z").fillet(0.8)
    except Exception:
        pass

    # Cross horn is a separate reference solid so it can be colored white.
    horn = cyl_z(4.8, 2.0, 3.8)
    horn = horn.union(box_at(-16.0, 16.0, -2.0, 2.0, 2.4, 3.8))
    horn = horn.union(box_at(-2.0, 2.0, -11.0, 11.0, 2.4, 3.8))
    horn = horn.cut(cyl_z(1.0, 1.8, 4.0))
    return body.clean(), horn.clean()


def make_c270_reference() -> tuple[cq.Workplane, cq.Workplane]:
    """A simplified C270 body and fixed-clip envelope for assembly visualization."""
    # Local tilt axis is Y through (0,0,0). The clip blade top is Z=6 mm.
    webcam = box_at(-C270_WIDTH / 2, C270_WIDTH / 2, 9.0, 31.0, 6.0, 6.0 + C270_HEIGHT)
    try:
        webcam = webcam.edges("|Y").fillet(7.0)
    except Exception:
        pass
    lens = cyl_y(7.0, 5.0, 9.2, -10.0, 6.0 + C270_HEIGHT * 0.58)
    lens = lens.union(cyl_y(3.8, 3.8, 5.2, -10.0, 6.0 + C270_HEIGHT * 0.58))
    webcam = webcam.union(lens).clean()

    # The clip is deliberately simplified but uses the complete supplied depth envelope.
    clip = box_at(-30.0, 30.0, 18.0, 18.0 + C270_DEPTH_WITH_CLIP - 22.0, -4.0, 8.0)
    try:
        clip = clip.edges("|Y").fillet(3.0)
    except Exception:
        pass
    return webcam, clip.clean()


def positioned_reference_models() -> dict[str, cq.Workplane]:
    servo_body, servo_horn = make_sg90_reference()
    pan_body = servo_body
    pan_horn = servo_horn
    tilt_body = servo_body.rotate((0, 0, 0), (1, 0, 0), -90.0).translate((0, 27.0, TILT_AXIS_Z))
    tilt_horn = servo_horn.rotate((0, 0, 0), (1, 0, 0), -90.0).translate((0, 27.0, TILT_AXIS_Z))
    webcam, clip = make_c270_reference()
    webcam = webcam.translate((0, 31.0, TILT_AXIS_Z))
    clip = clip.translate((0, 31.0, TILT_AXIS_Z))
    return {
        "SG90_Pan_Body": pan_body,
        "SG90_Pan_Horn": pan_horn,
        "SG90_Tilt_Body": tilt_body,
        "SG90_Tilt_Horn": tilt_horn,
        "C270_Webcam_Body": webcam,
        "C270_Fixed_Clip": clip,
    }


def export_part(shape: cq.Workplane, stem: str) -> None:
    exporters.export(shape, str(PRINT_DIR / f"{stem}.step"))
    exporters.export(
        shape,
        str(PRINT_DIR / f"{stem}.stl"),
        tolerance=0.03,
        angularTolerance=0.04,
    )


def export_reference_models() -> None:
    servo_body, servo_horn = make_sg90_reference()
    servo_assembly = cq.Assembly(name="SG90_Visual_Reference")
    servo_assembly.add(servo_body, name="SG90_Body", color=cq.Color(0.12, 0.35, 0.78))
    servo_assembly.add(servo_horn, name="SG90_Cross_Horn", color=cq.Color(0.95, 0.95, 0.92))
    servo_assembly.save(str(REF_DIR / "SG90_Visual_Reference.step"))

    webcam, clip = make_c270_reference()
    webcam_assembly = cq.Assembly(name="Logitech_C270_Visual_Reference")
    webcam_assembly.add(webcam, name="C270_Body", color=cq.Color(0.08, 0.09, 0.11))
    webcam_assembly.add(clip, name="C270_Fixed_Clip", color=cq.Color(0.18, 0.19, 0.22))
    webcam_assembly.save(str(REF_DIR / "Logitech_C270_Visual_Reference.step"))


def export_positioned_assemblies(
    arm: cq.Workplane, cap: cq.Workplane, camera: cq.Workplane, base: cq.Workplane
) -> None:
    printable = cq.Assembly(name="C270_PanTilt_Printable_Assembly")
    printable.add(base, name="PanServo_StabilityBase", color=cq.Color(0.28, 0.31, 0.36))
    printable.add(arm, name="CurvedArm_SG90_TiltHolder", color=cq.Color(0.18, 0.55, 0.92))
    printable.add(cap, name="SG90_RetainingCap", color=cq.Color(0.95, 0.62, 0.18))
    printable.add(
        camera,
        name="Logitech_C270_ClipCradle",
        loc=cq.Location(cq.Vector(0, 31.0, TILT_AXIS_Z)),
        color=cq.Color(0.18, 0.82, 0.58),
    )
    printable.save(str(ASM_DIR / "C270_PanTilt_Printable_Assembly.step"))

    assembly = cq.Assembly(name="C270_PanTilt_Full_Assembly_With_Servos")
    assembly.add(base, name="PanServo_StabilityBase", color=cq.Color(0.28, 0.31, 0.36))
    assembly.add(arm, name="CurvedArm_SG90_TiltHolder", color=cq.Color(0.18, 0.55, 0.92))
    assembly.add(cap, name="SG90_RetainingCap", color=cq.Color(0.95, 0.62, 0.18))
    assembly.add(
        camera,
        name="Logitech_C270_ClipCradle",
        loc=cq.Location(cq.Vector(0, 31.0, TILT_AXIS_Z)),
        color=cq.Color(0.18, 0.82, 0.58),
    )
    refs = positioned_reference_models()
    for name, shape in refs.items():
        if "Horn" in name:
            color = cq.Color(0.95, 0.95, 0.92)
        elif "SG90" in name:
            color = cq.Color(0.12, 0.35, 0.78)
        elif "Webcam" in name:
            color = cq.Color(0.07, 0.08, 0.10)
        else:
            color = cq.Color(0.18, 0.19, 0.22)
        assembly.add(shape, name=name, color=color)
    assembly.save(str(ASM_DIR / "C270_PanTilt_Full_Assembly_With_Servos.step"))


def write_report(
    arm: cq.Workplane,
    cap: cq.Workplane,
    camera: cq.Workplane,
    base: cq.Workplane,
) -> None:
    camera_shift_y = 31.0
    webcam_envelope = box_at(
        -C270_WIDTH / 2,
        C270_WIDTH / 2,
        9.0,
        9.0 + C270_DEPTH_WITH_CLIP,
        6.0,
        6.0 + C270_HEIGHT,
    )

    fixed = cq.Compound.makeCompound([arm.val(), cap.val(), base.val()])
    clearances = []
    for angle in (-45.0, 0.0, 45.0):
        env = webcam_envelope.rotate((0, 0, 0), (0, 1, 0), angle).translate(
            (0, camera_shift_y, TILT_AXIS_Z)
        )
        distance = fixed.distance(env.val())
        clearances.append((angle, distance))

    lever_mm = math.hypot(C270_DEPTH_WITH_CLIP / 2.0, 6.0 + C270_HEIGHT / 2.0)
    torque_kg_cm = (C270_MASS_G / 1000.0) * (lever_mm / 10.0)
    bb_arm = arm.val().BoundingBox()
    bb_cap = cap.val().BoundingBox()
    bb_cam = camera.val().BoundingBox()
    bb_base = base.val().BoundingBox()

    lines = [
        "C270 ROBOTIC ARM - REVISION D",
        "================================",
        "",
        "Architecture",
        "- Pan axis: Z (vertical), through the 40 mm bottom horn pad.",
        "- Tilt axis: Y (horizontal), at Z = 94 mm.",
        "- Axis relationship: exactly 90 degrees.",
        "- Intended software tilt limit: -45 to +45 degrees.",
        "- Curved-arm edges: exact analytic arcs with a 1 mm edge round; no segmented sketch ridges.",
        "",
        "Input dimensions",
        f"- C270 envelope: {C270_WIDTH:.2f} x {C270_HEIGHT:.2f} x {C270_DEPTH_WITH_CLIP:.2f} mm.",
        f"- C270 mass: {C270_MASS_G:.0f} g.",
        f"- Curved arm: R{ARM_CENTERLINE_RADIUS:.0f}, {ARM_WIDTH:.0f} mm wide, {ARM_THICKNESS:.0f} mm thick, {ARM_CENTER_SPACING:.0f} mm centres.",
        "",
        "Generated-part bounding boxes (X x Y x Z)",
        f"- Arm/holder: {bb_arm.xlen:.2f} x {bb_arm.ylen:.2f} x {bb_arm.zlen:.2f} mm.",
        f"- Servo cap: {bb_cap.xlen:.2f} x {bb_cap.ylen:.2f} x {bb_cap.zlen:.2f} mm.",
        f"- Camera cradle: {bb_cam.xlen:.2f} x {bb_cam.ylen:.2f} x {bb_cam.zlen:.2f} mm.",
        f"- Pan-servo stability base: {bb_base.xlen:.2f} x {bb_base.ylen:.2f} x {bb_base.zlen:.2f} mm.",
        f"- Stability footprint: {BASE_DIAMETER:.0f} mm nominal diameter; the edge-open rear channel leaves approximately {abs(bb_base.ymin):.1f} mm of rear support reach.",
        f"- Cable channel: {CABLE_CHANNEL_WIDTH:.0f} mm wide, full {BASE_THICKNESS:.0f} mm plate depth, open from beneath the pan servo to the rear rim.",
        "",
        "Conservative webcam-envelope clearance to the fixed arm/holder",
    ]
    for angle, distance in clearances:
        lines.append(f"- At {angle:+.0f} degrees: {distance:.2f} mm.")
    lines += [
        "",
        f"Static load estimate using a {lever_mm:.1f} mm combined depth/height lever: {torque_kg_cm:.3f} kg-cm.",
        "This excludes acceleration, cable pull, and impact loads.",
        "",
        "Fit and assembly notes",
        "1. Import STEP files into SolidWorks with 3D Interconnect enabled, then save as SLDPRT.",
        "2. Seat the pan SG90 upright on the stability base with its shaft pointing +Z; fasten its ears to the two M2 pilot holes.",
        "3. Lay the pan-servo lead, upper-servo lead, and webcam USB cable into the 22 mm full-depth rear channel. It is open at the rim, so connectors do not need to be pushed through a small hole.",
        "4. Insert the tilt SG90 from the +Y/front side with its shaft pointing +Y.",
        "5. Secure the cap with four M2 self-tapping screws. Use a thin foam shim if your SG90 clone is loose.",
        "6. Attach the camera cradle to the actual SG90 horn using the adaptable 3.2 mm centre and 2.0 mm pilot-hole pattern.",
        "7. Clamp the C270's fixed monitor clip over the cradle's 5 mm top blade. The right-side notch is the USB-cable exit.",
        "8. Set the servo neutral before installing the horn; enforce 45..135 degrees in software for a +/-45 degree tilt range.",
        "9. The four outer base holes can fasten the assembly to a board or accept rubber-foot hardware for additional stability.",
        "10. The included SG90 and C270 reference STEP models are visual proxies; compare the supplied SG90 model and physical hardware before final printing.",
        "",
        "Printing suggestion",
        "- PETG or PLA+, 0.20 mm layers, 4 perimeters, 35-45% infill.",
        "- Print the 140 mm stability base flat with its circular plate on the bed; no support should be needed for the plate itself.",
        "- Print the arm on a broad curved side, the cap on its 31 x 24 mm face, and the camera cradle on its long bottom edge with a brim.",
        "",
        "Package map",
        "- Printable_Parts: four individual STEP/STL printable components, including PanServo_StabilityBase.",
        "- Assemblies: printable assembly and a full visual assembly with two SG90 servos and a C270 proxy.",
        "- Reference_Models: generic SG90 and C270 visualization STEP files.",
        "- Documentation: illustrated build/printing guides, verification report, and this README.",
        "- Renders: neutral assembly, exploded parts, tilt range, and pan-base detail illustrations.",
        "- Source: parametric CAD generator used to create Revision D.",
        "- Verification_Report.txt: STEP re-import, single-solid, curve, and collision results.",
    ]
    (DOC_DIR / "README_Robotic_Arm_RevD.txt").write_text("\n".join(lines), encoding="utf-8")


def make_previews(
    arm: cq.Workplane,
    cap: cq.Workplane,
    camera: cq.Workplane,
    base: cq.Workplane,
) -> None:
    # VTK is bundled with the CadQuery kernel.  Use off-screen rendering so the
    # user gets a quick visual without changing their live SolidWorks session.
    from vtkmodules.vtkIOGeometry import vtkSTLReader
    from vtkmodules.vtkRenderingCore import (
        vtkActor,
        vtkPolyDataMapper,
        vtkRenderer,
        vtkRenderWindow,
    )
    from vtkmodules.vtkRenderingOpenGL2 import vtkOpenGLRenderer, vtkOpenGLRenderWindow  # noqa: F401
    from vtkmodules.vtkIOImage import vtkPNGWriter
    from vtkmodules.vtkRenderingCore import vtkWindowToImageFilter

    preview_dir = WORK / "preview_revC"
    preview_dir.mkdir(parents=True, exist_ok=True)
    def render_scene(filename, scene, camera_position, focal_point):
        renderer = vtkRenderer()
        renderer.SetBackground(0.965, 0.975, 0.99)
        for index, (name, shape, color, opacity) in enumerate(scene):
            path = preview_dir / f"{filename}_{index}_{name}.stl"
            exporters.export(shape, str(path), tolerance=0.04, angularTolerance=0.05)
            reader = vtkSTLReader()
            reader.SetFileName(str(path))
            mapper = vtkPolyDataMapper()
            mapper.SetInputConnection(reader.GetOutputPort())
            actor = vtkActor()
            actor.SetMapper(mapper)
            actor.GetProperty().SetColor(*color)
            actor.GetProperty().SetOpacity(opacity)
            actor.GetProperty().SetSpecular(0.22)
            actor.GetProperty().SetSpecularPower(20)
            renderer.AddActor(actor)

        window = vtkRenderWindow()
        window.SetOffScreenRendering(1)
        window.SetMultiSamples(8)
        window.SetSize(1400, 1000)
        window.AddRenderer(renderer)
        vtk_camera = renderer.GetActiveCamera()
        vtk_camera.SetPosition(*camera_position)
        vtk_camera.SetFocalPoint(*focal_point)
        vtk_camera.SetViewUp(0, 0, 1)
        renderer.ResetCameraClippingRange()
        window.Render()
        capture = vtkWindowToImageFilter()
        capture.SetInput(window)
        capture.ReadFrontBufferOff()
        capture.Update()
        writer = vtkPNGWriter()
        writer.SetFileName(str(RENDER_DIR / filename))
        writer.SetInputConnection(capture.GetOutputPort())
        writer.Write()

    blue = (0.12, 0.45, 0.86)
    orange = (0.96, 0.55, 0.12)
    green = (0.10, 0.72, 0.49)
    servo_blue = (0.08, 0.24, 0.62)
    white = (0.94, 0.94, 0.90)
    black = (0.06, 0.07, 0.09)
    dark_gray = (0.18, 0.19, 0.22)
    base_gray = (0.26, 0.29, 0.34)
    refs = positioned_reference_models()
    neutral_scene = [
        ("base", base, base_gray, 1.0),
        ("arm", arm, blue, 1.0),
        ("cap", cap, orange, 1.0),
        ("cradle", camera.translate((0, 31.0, TILT_AXIS_Z)), green, 1.0),
        ("pan_servo", refs["SG90_Pan_Body"], servo_blue, 1.0),
        ("pan_horn", refs["SG90_Pan_Horn"], white, 1.0),
        ("tilt_servo", refs["SG90_Tilt_Body"], servo_blue, 1.0),
        ("tilt_horn", refs["SG90_Tilt_Horn"], white, 1.0),
        ("webcam", refs["C270_Webcam_Body"], black, 1.0),
        ("webcam_clip", refs["C270_Fixed_Clip"], dark_gray, 1.0),
    ]
    render_scene(
        "01_Full_Assembly_With_Servos.png",
        neutral_scene,
        (230, -330, 190),
        (0, 14, 42),
    )

    exploded_scene = [
        ("base", base.translate((-65, 35, -12)), base_gray, 1.0),
        ("arm", arm.translate((-50, -28, 18)), blue, 1.0),
        ("cap", cap.translate((25, -10, -55)), orange, 1.0),
        ("cradle", camera.translate((88, 0, 66)), green, 1.0),
    ]
    render_scene(
        "02_Exploded_Printable_Parts.png",
        exploded_scene,
        (265, -365, 210),
        (0, 0, 38),
    )

    webcam_local, clip_local = make_c270_reference()
    moving_local = cq.Compound.makeCompound([camera.val(), webcam_local.val(), clip_local.val()])
    tilt_scene = [
        ("base", base, base_gray, 1.0),
        ("arm", arm, blue, 1.0),
        ("cap", cap, orange, 1.0),
        ("pan_servo", refs["SG90_Pan_Body"], servo_blue, 1.0),
        ("tilt_servo", refs["SG90_Tilt_Body"], servo_blue, 1.0),
    ]
    for label, angle, color, opacity in (
        ("minus45", -45.0, (0.22, 0.67, 0.96), 0.35),
        ("neutral", 0.0, green, 0.82),
        ("plus45", 45.0, (0.63, 0.32, 0.91), 0.35),
    ):
        moved = cq.Workplane(obj=moving_local).rotate((0, 0, 0), (0, 1, 0), angle).translate(
            (0, 31.0, TILT_AXIS_Z)
        )
        tilt_scene.append((label, moved, color, opacity))
    render_scene(
        "03_Tilt_Range_Minus45_to_Plus45.png",
        tilt_scene,
        (235, -345, 175),
        (0, 20, 55),
    )

    base_scene = [
        ("base", base, base_gray, 1.0),
        ("pan_servo", refs["SG90_Pan_Body"], servo_blue, 1.0),
        ("pan_horn", refs["SG90_Pan_Horn"], white, 1.0),
    ]
    render_scene(
        "04_Pan_Servo_Stability_Base.png",
        base_scene,
        (145, -205, 92),
        (0, 0, -9),
    )


def main() -> None:
    arm = make_arm_and_holder()
    cap = make_servo_cap()
    camera = make_camera_clip_cradle()
    base = make_pan_servo_stability_base()
    export_part(arm, "CurvedArm_SG90_TiltHolder")
    export_part(cap, "SG90_RetainingCap")
    export_part(camera, "Logitech_C270_ClipCradle")
    export_part(base, "PanServo_StabilityBase")
    export_reference_models()
    export_positioned_assemblies(arm, cap, camera, base)
    write_report(arm, cap, camera, base)
    make_previews(arm, cap, camera, base)
    print("Generated robotic-arm deliverables in", OUT)


if __name__ == "__main__":
    main()
