from collections import Counter
from pathlib import Path
import importlib.util

import cadquery as cq


ROOT = Path(r"C:\Users\zongs\Documents\Codex\2026-08-20\can-y")
OUT = ROOT / "outputs" / "C270_Robotic_Arm_RevD"


def load_generator():
    path = ROOT / "work" / "generate_robotic_arm_revD.py"
    spec = importlib.util.spec_from_file_location("arm_revd", path)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


print("STEP RE-IMPORT CHECK")
step_counts = {}
for path in sorted(OUT.rglob("*.step")):
    shape = cq.importers.importStep(str(path))
    solids = shape.solids().vals()
    valid = all(s.isValid() for s in solids)
    relative = str(path.relative_to(OUT)).replace("\\", "/")
    step_counts[relative] = len(solids)
    print(f"{relative} | solids={len(solids)} | valid={valid}")

g = load_generator()
arm = g.make_arm_and_holder()
cap = g.make_servo_cap()
base = g.make_pan_servo_stability_base()
refs = g.positioned_reference_models()

edge_types = Counter(edge.geomType() for edge in arm.edges().vals())
print("\nARM EDGE TYPES", dict(edge_types))
print("Arm exact-circle edges:", edge_types.get("CIRCLE", 0))
print("Arm spline edges:", edge_types.get("BSPLINE", 0))


def intersection_volume(a, b):
    result = a.intersect(b)
    return sum(s.Volume() for s in result.solids().vals())


checks = {
    "pan servo body vs arm": intersection_volume(refs["SG90_Pan_Body"], arm),
    "pan horn vs arm": intersection_volume(refs["SG90_Pan_Horn"], arm),
    "pan servo body vs stability base": intersection_volume(refs["SG90_Pan_Body"], base),
    "pan horn vs stability base": intersection_volume(refs["SG90_Pan_Horn"], base),
    "stability base vs arm": intersection_volume(base, arm),
    "tilt servo body vs arm": intersection_volume(refs["SG90_Tilt_Body"], arm),
    "tilt servo body vs cap": intersection_volume(refs["SG90_Tilt_Body"], cap),
    "tilt horn vs cap": intersection_volume(refs["SG90_Tilt_Horn"], cap),
}
print("\nREFERENCE COLLISION CHECK (mm^3)")
for name, volume in checks.items():
    print(f"{name}: {volume:.4f}")

base_bb = base.val().BoundingBox()
print("\nSTABILITY BASE")
print(f"Bounding box: {base_bb.xlen:.2f} x {base_bb.ylen:.2f} x {base_bb.zlen:.2f} mm")
print(f"Volume: {base.val().Volume():.2f} mm^3")
if abs(base_bb.xlen - g.BASE_DIAMETER) > 0.05 or base_bb.ylen < 139.0:
    raise SystemExit("VERIFY FAILED: stability-base footprint is smaller than expected after the rear channel cut")

# Confirm the new wiring route is a true through-channel rather than a shallow
# recess.  The probe stays inside the nominal 22 mm channel and plate depth.
channel_probe = g.box_at(-10.5, 10.5, -69.0, 6.5, g.BASE_BOTTOM_Z - 0.1, g.BASE_TOP_Z + 0.1)
channel_blockage = intersection_volume(base, channel_probe)
print(f"Cable channel: {g.CABLE_CHANNEL_WIDTH:.2f} mm wide, edge-open, blockage={channel_blockage:.4f} mm^3")

failed = []
expected_counts = {
    "Printable_Parts/CurvedArm_SG90_TiltHolder.step": 1,
    "Printable_Parts/SG90_RetainingCap.step": 1,
    "Printable_Parts/Logitech_C270_ClipCradle.step": 1,
    "Printable_Parts/PanServo_StabilityBase.step": 1,
    "Assemblies/C270_PanTilt_Printable_Assembly.step": 4,
    "Assemblies/C270_PanTilt_Full_Assembly_With_Servos.step": 10,
    "Reference_Models/SG90_Visual_Reference.step": 2,
    "Reference_Models/Logitech_C270_Visual_Reference.step": 2,
}
for relative, expected in expected_counts.items():
    actual = step_counts.get(relative)
    if actual != expected:
        failed.append(f"{relative}: expected {expected} solids, found {actual}")
for path in sorted(OUT.rglob("*.step")):
    shape = cq.importers.importStep(str(path))
    if not all(s.isValid() for s in shape.solids().vals()):
        failed.append(str(path))
for name, volume in checks.items():
    if volume > 0.10:
        failed.append(f"{name}={volume:.4f} mm^3")
if channel_blockage > 0.10:
    failed.append(f"cable channel blockage={channel_blockage:.4f} mm^3")
if failed:
    raise SystemExit("VERIFY FAILED: " + "; ".join(failed))
print("\nVERIFY PASSED")
