C270 ROBOTIC ARM - REVISION I
================================

WHAT TO PRINT FOR THIS UPDATE
- If you already printed Revision H, print only Printable_Parts\Logitech_C270_ScrewlessCradle.stl.
- The arm, stability base, and orange retaining cap are unchanged and can be reused.
- Print individual STL files, not either STEP assembly. The assembly files are for viewing and SolidWorks positioning.
- The webcam receives no screws. Its attached cable leaves through the completely open rear aperture.

Architecture
- Pan axis: Z (vertical), through the 40 mm bottom horn pad.
- Tilt axis: Y (horizontal), at Z = 94 mm.
- Axis relationship: exactly 90 degrees.
- Intended software tilt limit: -45 to +45 degrees.
- Curved-arm edges: exact analytic arcs with a 1 mm edge round; no segmented sketch ridges.

Input dimensions
- C270 envelope: 72.91 x 31.91 x 66.64 mm.
- C270 mass: 75 g.
- Curved arm: R50, 14 mm wide, 6 mm thick, 80 mm centres.
- Supplied User Library-SG90.sldprt: 32.5 x 30.1 x 12.5 mm exported envelope; mounting-ear slot centres 27.5 mm apart.

Generated-part bounding boxes (X x Y x Z)
- Arm/holder: 47.00 x 44.00 x 104.00 mm.
- Servo cap: 31.00 x 3.00 x 24.00 mm.
- Screwless camera cradle: 79.71 x 34.40 x 65.31 mm.
- Nominal C270 body fit clearance: 0.60 mm per side.
- Cradle rear aperture: 74.11 mm clear inside width; no rear wall, lower rail, or cross-member.
- Cradle underside: open through the middle for the permanently attached monitor clip.
- Webcam fastening: screwless; corner shelves, flexible side cheeks, 0.15 mm side-grip preload, and top/front corner lips capture the body.
- Pan-servo stability base: 140.00 x 140.00 x 18.60 mm after STEP re-import.
- Stability footprint: 140 mm diameter (70 mm radius in every pan direction).
- Pan-servo side ports: two openings, each 14 x 9 mm, feeding 14 mm-wide side grooves.
- Arm cable routing: two rounded side-entry openings, each 16 x 10 mm; the back wall remains intact.
- Pan-servo ear pilots: 27.5 mm centre spacing, 1.9 mm pilot diameter for M2 self-tapping screws.
- Tilt-cap screw pattern: 27.7 x 15.0 mm centres; 1.8 mm holder pilots and 2.4 mm cap clearances.
- Servo-horn interfaces: 3.2 mm centre clearance plus four 2.0 mm pilots on a 7.0 mm radius.

Conservative webcam-envelope clearance to the fixed arm/holder
- At -45 degrees: 13.00 mm.
- At +0 degrees: 13.00 mm.
- At +45 degrees: 13.00 mm.

Static load estimate using a 39.9 mm combined depth/height lever: 0.299 kg-cm.
This excludes acceleration, cable pull, and impact loads.

Fit and assembly notes
1. Import STEP files into SolidWorks with 3D Interconnect enabled, then save as SLDPRT.
2. Seat the pan SG90 upright on the stability base with its shaft pointing +Z; fasten its ears to the two M2 pilot holes.
3. Point the pan-servo wire toward either gray side tower, pass its plug through the 14 x 9 mm side window, and lay the lead in that side's 14 mm-wide groove.
4. Insert the tilt SG90 from the +Y/front side with its shaft pointing +Y.
5. Secure the cap with four M2 self-tapping screws. Use a thin foam shim if your SG90 clone is loose.
6. Attach the printed screwless cradle to the actual SG90 horn using the adaptable 3.2 mm centre and 2.0 mm pilot-hole pattern. These screws attach only to the horn, never to the webcam.
7. Lower the C270 body into the green basket from above. Let the two corner shelves support its lower edges while the permanently attached monitor clip hangs freely through the open middle underside.
8. Ease the flexible top corner lips over the webcam body. Confirm that the front lens/microphone area is unobstructed and the body cannot slide forward, backward, or sideways.
9. Let the attached USB cable leave straight through the completely open back of the green cradle. Curve it around either green side, then pass it through either rounded 16 x 10 mm side window in the blue upper holder. Do not cut the blue back wall; leave a loose service loop.
10. Set the servo neutral before installing the horn; enforce 45..135 degrees in software for a +/-45 degree tilt range.
11. The four outer base holes can fasten the assembly to a board or accept rubber-foot hardware for additional stability.
12. The included SG90 and C270 reference STEP models are visual proxies; test-fit the physical webcam gently before forcing the flexible lips.

Printing suggestion
- PETG or PLA+, 0.20 mm layers, 4 perimeters, 35-45% infill.
- Print the 140 mm stability base flat with its circular plate on the bed; keep both tower windows and side grooves clear of support.
- Print the arm on a broad curved side and the cap on its 31 x 24 mm face.
- Print the screwless cradle on one broad outer side wall with a brim; use build-plate-only organic support beneath the horn boss only if Preview shows an unsupported start.

Package map
- Printable_Parts: four individual STEP/STL printable components, including PanServo_StabilityBase.
- Assemblies: printable assembly and a full visual assembly with two SG90 servos and a C270 proxy.
- Reference_Models: generic SG90 and C270 visualization STEP files.
- Documentation: illustrated build/printing guides, verification report, and this README.
- Renders: neutral assembly, exploded parts, tilt range, pan-base detail, arm side-exit detail, and screwless-cradle detail illustrations.
- Source: Revision I parametric CAD generator, CAD verifier, and both document generators.
- Verification_Report.txt: STEP re-import, single-solid, curve, and collision results.
