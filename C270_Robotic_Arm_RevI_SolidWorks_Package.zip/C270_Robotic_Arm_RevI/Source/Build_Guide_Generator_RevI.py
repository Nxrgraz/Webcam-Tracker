from pathlib import Path
from datetime import date

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_ALIGN_VERTICAL
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK, WD_LINE_SPACING, WD_TAB_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor


ROOT = Path(r"C:\Users\zongs\Documents\Codex\2026-08-20\can-y")
PACKAGE = ROOT / "outputs" / "C270_Robotic_Arm_RevI"
DOC_DIR = PACKAGE / "Documentation"
RENDER_DIR = PACKAGE / "Renders"
OUT = DOC_DIR / "C270_Robotic_Arm_Complete_Build_Guide.docx"

# compact_reference_guide preset tokens
FONT = "Calibri"
NAVY = "203748"
BLUE = "2E74B5"
DARK_BLUE = "1F4D78"
GOLD = "B88422"
MUTED = "5E6B78"
LIGHT_BLUE = "E8EEF5"
LIGHT_GRAY = "F2F4F7"
PALE_GREEN = "E9F6F1"
WHITE = "FFFFFF"
CONTENT_DXA = 9360
TABLE_INDENT_DXA = 120
PAGE_BREAK_PENDING = False


def rgb(hex_color):
    return RGBColor.from_string(hex_color)


def set_run_font(run, size=None, color=None, bold=None, italic=None, name=FONT):
    run.font.name = name
    run._element.get_or_add_rPr().rFonts.set(qn("w:ascii"), name)
    run._element.get_or_add_rPr().rFonts.set(qn("w:hAnsi"), name)
    if size is not None:
        run.font.size = Pt(size)
    if color is not None:
        run.font.color.rgb = rgb(color)
    if bold is not None:
        run.bold = bold
    if italic is not None:
        run.italic = italic


def set_style(style, size, color, before, after, line=1.25, bold=None):
    style.font.name = FONT
    style._element.get_or_add_rPr().rFonts.set(qn("w:ascii"), FONT)
    style._element.get_or_add_rPr().rFonts.set(qn("w:hAnsi"), FONT)
    style.font.size = Pt(size)
    style.font.color.rgb = rgb(color)
    if bold is not None:
        style.font.bold = bold
    pf = style.paragraph_format
    pf.space_before = Pt(before)
    pf.space_after = Pt(after)
    pf.line_spacing = line


def shade_paragraph(paragraph, fill):
    p_pr = paragraph._p.get_or_add_pPr()
    shd = p_pr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        p_pr.append(shd)
    shd.set(qn("w:fill"), fill)


def set_cell_shading(cell, fill):
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = tc_pr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        tc_pr.append(shd)
    shd.set(qn("w:fill"), fill)


def set_cell_margins(cell, top=80, start=120, bottom=80, end=120):
    tc = cell._tc
    tc_pr = tc.get_or_add_tcPr()
    tc_mar = tc_pr.first_child_found_in("w:tcMar")
    if tc_mar is None:
        tc_mar = OxmlElement("w:tcMar")
        tc_pr.append(tc_mar)
    for tag, value in (("top", top), ("start", start), ("bottom", bottom), ("end", end)):
        node = tc_mar.find(qn(f"w:{tag}"))
        if node is None:
            node = OxmlElement(f"w:{tag}")
            tc_mar.append(node)
        node.set(qn("w:w"), str(value))
        node.set(qn("w:type"), "dxa")


def set_table_geometry(table, widths_dxa):
    assert sum(widths_dxa) == CONTENT_DXA
    table.autofit = False
    tbl_pr = table._tbl.tblPr
    tbl_w = tbl_pr.find(qn("w:tblW"))
    if tbl_w is None:
        tbl_w = OxmlElement("w:tblW")
        tbl_pr.append(tbl_w)
    tbl_w.set(qn("w:w"), str(CONTENT_DXA))
    tbl_w.set(qn("w:type"), "dxa")
    tbl_ind = tbl_pr.find(qn("w:tblInd"))
    if tbl_ind is None:
        tbl_ind = OxmlElement("w:tblInd")
        tbl_pr.append(tbl_ind)
    tbl_ind.set(qn("w:w"), str(TABLE_INDENT_DXA))
    tbl_ind.set(qn("w:type"), "dxa")
    layout = tbl_pr.find(qn("w:tblLayout"))
    if layout is None:
        layout = OxmlElement("w:tblLayout")
        tbl_pr.append(layout)
    layout.set(qn("w:type"), "fixed")
    grid_cols = table._tbl.tblGrid.gridCol_lst
    for index, width in enumerate(widths_dxa):
        grid_cols[index].set(qn("w:w"), str(width))
    for row in table.rows:
        for index, cell in enumerate(row.cells):
            cell.width = Inches(widths_dxa[index] / 1440)
            tc_w = cell._tc.get_or_add_tcPr().get_or_add_tcW()
            tc_w.set(qn("w:w"), str(widths_dxa[index]))
            tc_w.set(qn("w:type"), "dxa")
            cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
            set_cell_margins(cell)


def repeat_header(row):
    tr_pr = row._tr.get_or_add_trPr()
    header = OxmlElement("w:tblHeader")
    header.set(qn("w:val"), "true")
    tr_pr.append(header)


def style_table(table, header=True, font_size=9.5):
    table.style = "Table Grid"
    for row_index, row in enumerate(table.rows):
        for cell in row.cells:
            if header and row_index == 0:
                set_cell_shading(cell, LIGHT_BLUE)
            for paragraph in cell.paragraphs:
                paragraph.paragraph_format.space_before = Pt(0)
                paragraph.paragraph_format.space_after = Pt(0)
                paragraph.paragraph_format.line_spacing = 1.15
                for run in paragraph.runs:
                    set_run_font(
                        run,
                        size=font_size,
                        color=NAVY,
                        bold=(header and row_index == 0),
                    )
    if header:
        repeat_header(table.rows[0])


def add_table(doc, headers, rows, widths):
    table = doc.add_table(rows=1, cols=len(headers))
    for i, header in enumerate(headers):
        table.rows[0].cells[i].text = header
    for values in rows:
        cells = table.add_row().cells
        for i, value in enumerate(values):
            cells[i].text = str(value)
    set_table_geometry(table, widths)
    style_table(table)
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(2)
    return table


def add_heading(doc, text, level=1):
    global PAGE_BREAK_PENDING
    p = doc.add_paragraph(text, style=f"Heading {level}")
    if PAGE_BREAK_PENDING:
        p.paragraph_format.page_break_before = True
        PAGE_BREAK_PENDING = False
    p.paragraph_format.keep_with_next = True
    return p


def add_body(doc, text, bold_lead=None):
    p = doc.add_paragraph()
    if bold_lead and text.startswith(bold_lead):
        lead = p.add_run(bold_lead)
        set_run_font(lead, bold=True, color=NAVY)
        rest = p.add_run(text[len(bold_lead):])
        set_run_font(rest, color=NAVY)
    else:
        r = p.add_run(text)
        set_run_font(r, color=NAVY)
    return p


def add_bullet(doc, text):
    p = doc.add_paragraph(style="List Bullet")
    p.paragraph_format.left_indent = Inches(0.375)
    p.paragraph_format.first_line_indent = Inches(-0.188)
    p.paragraph_format.space_after = Pt(4)
    p.paragraph_format.line_spacing = 1.25
    set_run_font(p.add_run(text), color=NAVY)
    return p


def new_numbering_instance(doc, start=1):
    style = doc.styles["List Number"]
    base_num_id = int(style._element.pPr.numPr.numId.val)
    numbering = doc.part.numbering_part.element
    base_num = next(
        node for node in numbering.findall(qn("w:num"))
        if int(node.get(qn("w:numId"))) == base_num_id
    )
    abstract_id = int(base_num.find(qn("w:abstractNumId")).get(qn("w:val")))
    existing = [int(node.get(qn("w:numId"))) for node in numbering.findall(qn("w:num"))]
    new_id = max(existing) + 1
    num = OxmlElement("w:num")
    num.set(qn("w:numId"), str(new_id))
    abstract = OxmlElement("w:abstractNumId")
    abstract.set(qn("w:val"), str(abstract_id))
    num.append(abstract)
    override = OxmlElement("w:lvlOverride")
    override.set(qn("w:ilvl"), "0")
    start_override = OxmlElement("w:startOverride")
    start_override.set(qn("w:val"), str(start))
    override.append(start_override)
    num.append(override)
    numbering.append(num)
    return new_id


def add_number(doc, text, num_id):
    p = doc.add_paragraph(style="List Number")
    p_pr = p._p.get_or_add_pPr()
    num_pr = p_pr.get_or_add_numPr()
    num_pr.get_or_add_ilvl().val = 0
    num_pr.get_or_add_numId().val = num_id
    p.paragraph_format.left_indent = Inches(0.375)
    p.paragraph_format.first_line_indent = Inches(-0.188)
    p.paragraph_format.space_after = Pt(5)
    p.paragraph_format.line_spacing = 1.25
    set_run_font(p.add_run(text), color=NAVY)
    return p


def add_callout(doc, label, text, fill=PALE_GREEN):
    p = doc.add_paragraph()
    p.paragraph_format.left_indent = Inches(0.12)
    p.paragraph_format.right_indent = Inches(0.12)
    p.paragraph_format.space_before = Pt(4)
    p.paragraph_format.space_after = Pt(10)
    shade_paragraph(p, fill)
    lead = p.add_run(label + "  ")
    set_run_font(lead, size=10.5, color=DARK_BLUE, bold=True)
    run = p.add_run(text)
    set_run_font(run, size=10.5, color=NAVY)
    return p


def add_picture(doc, path, width_inches, alt_text, caption):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(4)
    p.paragraph_format.space_after = Pt(3)
    run = p.add_run()
    shape = run.add_picture(str(path), width=Inches(width_inches))
    doc_pr = shape._inline.docPr
    doc_pr.set("descr", alt_text)
    doc_pr.set("title", caption)
    cp = doc.add_paragraph(style="Caption")
    cp.alignment = WD_ALIGN_PARAGRAPH.CENTER
    cp.paragraph_format.keep_with_next = False
    cp.paragraph_format.space_after = Pt(8)
    r = cp.add_run(caption)
    set_run_font(r, size=9, color=MUTED, italic=True)
    return p


def add_page_number(paragraph):
    run = paragraph.add_run()
    fld_char1 = OxmlElement("w:fldChar")
    fld_char1.set(qn("w:fldCharType"), "begin")
    instr = OxmlElement("w:instrText")
    instr.set(qn("xml:space"), "preserve")
    instr.text = " PAGE "
    fld_char2 = OxmlElement("w:fldChar")
    fld_char2.set(qn("w:fldCharType"), "end")
    run._r.extend([fld_char1, instr, fld_char2])
    set_run_font(run, size=9, color=MUTED)


def configure_document(doc):
    section = doc.sections[0]
    section.page_width = Inches(8.5)
    section.page_height = Inches(11)
    section.top_margin = Inches(1.0)
    section.right_margin = Inches(1.0)
    section.bottom_margin = Inches(1.0)
    section.left_margin = Inches(1.0)
    section.header_distance = Inches(0.492)
    section.footer_distance = Inches(0.492)

    styles = doc.styles
    set_style(styles["Normal"], 11, NAVY, 0, 6, 1.25)
    set_style(styles["Heading 1"], 16, BLUE, 18, 10, 1.0, True)
    set_style(styles["Heading 2"], 13, BLUE, 14, 7, 1.0, True)
    set_style(styles["Heading 3"], 12, DARK_BLUE, 10, 5, 1.0, True)
    set_style(styles["Caption"], 9, MUTED, 2, 8, 1.0, False)
    set_style(styles["List Bullet"], 11, NAVY, 0, 4, 1.25)
    set_style(styles["List Number"], 11, NAVY, 0, 5, 1.25)

    header = section.header
    hp = header.paragraphs[0]
    hp.paragraph_format.space_after = Pt(0)
    hp.paragraph_format.tab_stops.add_tab_stop(Inches(6.5), WD_TAB_ALIGNMENT.RIGHT)
    set_run_font(hp.add_run("C270 Pan-Tilt Robotic Arm"), size=9, color=MUTED, bold=True)
    set_run_font(hp.add_run("\tRevision I | August 2026"), size=9, color=MUTED)

    footer = section.footer
    fp = footer.paragraphs[0]
    fp.paragraph_format.space_before = Pt(0)
    fp.paragraph_format.tab_stops.add_tab_stop(Inches(6.5), WD_TAB_ALIGNMENT.RIGHT)
    set_run_font(fp.add_run("SolidWorks-ready design package"), size=9, color=MUTED)
    set_run_font(fp.add_run("\tPage "), size=9, color=MUTED)
    add_page_number(fp)


def page_break(doc):
    global PAGE_BREAK_PENDING
    PAGE_BREAK_PENDING = True


def build():
    doc = Document()
    configure_document(doc)

    # Cover - editorial_cover pattern with the compact reference preset.
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(14)
    p.paragraph_format.space_after = Pt(8)
    set_run_font(p.add_run("MECHANICAL BUILD GUIDE"), size=10.5, color=GOLD, bold=True)

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(5)
    set_run_font(p.add_run("C270 Pan-Tilt Robotic Arm"), size=29, color=NAVY, bold=True)
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(12)
    set_run_font(
        p.add_run("Smooth curved arm, dual SG90 servos, anti-tip pan base, screwless webcam cradle, and SolidWorks workflow"),
        size=13,
        color=MUTED,
    )
    add_picture(
        doc,
        RENDER_DIR / "01_Full_Assembly_With_Servos.png",
        5.75,
        "Isometric view of the smooth curved pan-tilt arm on a wide circular stability base with two blue SG90 servos and a black Logitech C270 webcam.",
        "Figure 1. Revision I full assembly with the C270 captured by the green screwless basket cradle.",
    )
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(2)
    p.paragraph_format.space_after = Pt(4)
    set_run_font(p.add_run("Revision I | 28 August 2026"), size=10.5, color=GOLD, bold=True)
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    set_run_font(
        p.add_run("Prepared for a Logitech C270 (72.91 x 31.91 x 66.64 mm, 75 g)"),
        size=9.5,
        color=MUTED,
        italic=True,
    )

    page_break(doc)
    add_heading(doc, "1. Design summary", 1)
    add_callout(
        doc,
        "DESIGN STATUS",
        "Revision I keeps the verified Revision H arm, base, and servo cap unchanged. Only the green cradle changes: its rear wall, lower rail, and rear corner material are removed across the complete 74.11 mm inner width. The C270 lead can now leave straight backward at any height. Two shallow flexible side-grip ribs replace the removed rear stop, while the fixed monitor clip remains free through the open underside.",
    )
    add_body(
        doc,
        "This mechanism provides horizontal pan at the bottom servo and vertical tilt at the top servo. The pan axis is vertical (Z), the tilt axis is horizontal (Y), and the axes are exactly perpendicular. No screw enters the webcam: screws are used only between the printed cradle and the SG90 horn.",
    )
    add_heading(doc, "Key design dimensions", 2)
    add_table(
        doc,
        ["Parameter", "Revision I value"],
        [
            ("Curved-arm centerline", "R50 mm exact circular arc"),
            ("Arm center spacing", "80 mm"),
            ("Arm width / thickness", "14 mm / 6 mm"),
            ("Tilt axis height", "94 mm above the model origin"),
            ("Webcam tilt command", "+/-45 degrees (90 degrees total)"),
            ("Upper-holder cable exits", "Two rounded 16 x 10 mm side windows; no rear cable opening"),
            ("Base mounting", "27.5 mm M2 ear-pilot spacing; 1.9 mm pilot diameter; 2 strap slots; 4 M4-class outer holes"),
            ("Tilt-cap fastening", "27.7 x 15.0 mm centres; 1.8 mm holder pilots and 2.4 mm cap clearances"),
            ("Servo-horn pattern", "3.2 mm centre clearance plus four 2.0 mm pilots on a 7 mm radius"),
            ("Estimated static tilt load", "About 0.30 kg-cm before dynamic and cable loads"),
        ],
        [2700, 6660],
    )
    page_break(doc)
    add_heading(doc, "Exploded printable parts", 1)
    add_body(
        doc,
        "Revision I is divided into four printable components. The gray base, blue arm, and orange servo cap are unchanged. Only the green webcam cradle is updated from Revision H, replacing the partly notched back with a completely open 74.11 mm-wide rear aperture.",
    )
    add_picture(
        doc,
        RENDER_DIR / "02_Exploded_Printable_Parts.png",
        5.65,
        "Exploded rendering of the gray circular pan base, blue curved arm, orange SG90 retaining cap, and green Logitech C270 screwless basket cradle.",
        "Figure 2. The four printable Revision I components supplied individually in STEP and STL formats.",
    )
    add_table(
        doc,
        ["Render color", "Component", "Assembly role"],
        [
            ("Dark gray", "Pan-servo stability base", "Wide footprint, side-exit windows and grooves, pan-SG90 ear mounts, and table holes"),
            ("Blue", "Curved arm + tilt holder", "Main structure, perpendicular servo cage, and two rounded side cable exits"),
            ("Orange", "SG90 retaining cap", "Removable tilt-servo restraint"),
            ("Green", "C270 screwless cradle", "Captures the webcam body; open underside leaves the fixed clip free"),
        ],
        [1400, 2950, 5010],
    )

    page_break(doc)
    add_heading(doc, "Screwless webcam cradle", 1)
    add_picture(
        doc,
        RENDER_DIR / "06_Screwless_C270_Cradle.png",
        5.35,
        "Rear view of the green one-piece C270 basket surrounding only the sides of the webcam body, with the entire rear face exposed, the fixed clip hanging underneath, and the USB cable leaving straight backward.",
        "Figure 3. The webcam is retained by the printed basket geometry; no fastener enters the C270.",
    )
    add_callout(
        doc,
        "HOW IT HOLDS THE CAMERA",
        "The two corner shelves support the lower body edges. Flexible side cheeks and two 0.15 mm-preload side-grip ribs resist sideways and backward movement, while the front/top corner lips prevent lifting or forward movement. The centre underside stays open for the attached monitor clip. Nothing crosses behind the webcam: the complete 74.11 mm inner width is open from below the shelves to above the top lips, so the attached cable and molded strain relief cannot meet a hidden rear strip.",
        fill=PALE_GREEN,
    )

    page_break(doc)
    add_heading(doc, "2. Parts and hardware", 1)
    add_heading(doc, "Printable components", 2)
    add_table(
        doc,
        ["Part", "Files supplied", "Purpose"],
        [
            ("Pan-servo stability base", "PanServo_StabilityBase.step / .stl", "Supports the upright pan SG90 and routes its side-exiting lead through either 14 x 9 mm tower window and matching groove."),
            ("Curved arm + tilt holder", "CurvedArm_SG90_TiltHolder.step / .stl", "Carries the pan pad and sideways tilt-servo cage with two rounded 16 x 10 mm side cable windows."),
            ("SG90 retaining cap", "SG90_RetainingCap.step / .stl", "Closes the tilt-servo cage while leaving the output tower and horn clear."),
            ("C270 screwless cradle", "Logitech_C270_ScrewlessCradle.step / .stl", "Captures the webcam body without screws and attaches to the tilt horn."),
        ],
        [1650, 3100, 4610],
    )
    add_heading(doc, "Purchased and reusable hardware", 2)
    for item in (
        "2 x SG90 micro servos: one pan servo and one tilt servo.",
        "1 x Logitech C270 HD webcam with its fixed mounting clip and USB cable.",
        "The two SG90 horns supplied with the servos, plus their center retaining screws.",
        "2 x M2 self-tapping servo screws for the pan SG90 ears: 27.5 mm centres into 1.9 mm printed pilots.",
        "4 x M2 self-tapping screws, approximately 6-8 mm long, for the orange cap: 27.7 x 15.0 mm centre pattern, 1.8 mm holder pilots, and 2.4 mm cap clearances.",
        "Optional: 4 x M4 bolts/screws or adhesive rubber feet for the gray base's outer mounting points.",
    ):
        add_bullet(doc, item)
    add_heading(doc, "Recommended print setup", 2)
    add_table(
        doc,
        ["Setting", "Recommendation", "Reason"],
        [
            ("Material", "PETG or PLA+", "Stiff enough for the 75 g webcam while remaining easy to print."),
            ("Layer height", "0.20 mm", "Good balance of accuracy and print time."),
            ("Walls", "4 perimeters", "Strengthens the curved arm and screw areas."),
            ("Infill", "35-45%", "Reduces flex without excessive weight."),
            ("Stability base", "Circular plate flat on bed", "Needs no support; use a brim if the 140 mm rim lifts."),
        ],
        [1600, 2200, 5560],
    )

    page_break(doc)
    add_heading(doc, "3. Mechanical assembly", 1)
    add_callout(
        doc,
        "BEFORE ASSEMBLY",
        "Power each servo and command it to its neutral position before installing either horn. A centered horn gives equal travel in both directions and prevents the webcam from hitting a software or mechanical limit during startup.",
        fill=LIGHT_BLUE,
    )
    steps = [
        "Inspect all four printed parts. Remove strings and support material, confirm the servo slides into the blue cage, and test the orange-cap and gray-base pilot holes by hand.",
        "Place the gray stability base flat. Add rubber feet, or use its four outer M4-class holes to fasten it to a board when extra security is required.",
        "Orient the pan SG90 so its wire exits toward either gray side tower. Pass the servo plug through that tower's 14 x 9 mm window, lay the lead in the matching 14 mm-wide side groove, then seat the servo upright with its shaft pointing +Z.",
        "Fasten the pan SG90 mounting ears to the two 1.9 mm M2 pilot holes on 27.5 mm centres, matching the supplied SG90 model. If a clone's ear slots differ, use a narrow zip tie through the two backup strap slots instead.",
        "Attach the blue 40 mm pan pad to the pan-servo horn. Use the center clearance hole and whichever 2.0 mm pilot holes match your actual horn. The raised pad leaves clearance beneath the curved upright.",
        "Install the curved arm/horn assembly on the centered pan servo. Confirm that rotating the pan servo turns the entire arm without the upright rubbing the horn, servo, or base.",
        "Rotate the second SG90 onto its side and slide it into the blue top cage from the front (+Y). Its output shaft must point horizontally toward the orange cap and webcam cradle.",
        "Install the orange retaining cap with four M2 self-tapping screws. The pattern is 27.7 x 15.0 mm, with 1.8 mm pilots in blue and 2.4 mm clearances in orange. Tighten evenly and stop when the servo cannot move.",
        "Attach the green screwless cradle to the tilt-servo horn. Start with the horn centered and use the adaptable center/pilot-hole pattern to match the physical horn. These screws attach only to the horn, not to the webcam.",
        "Lower the C270 body into the basket from above. Its permanently attached monitor clip must hang through the open centre underside without being squeezed between printed surfaces.",
        "Ease the flexible top corner lips over the webcam body. Confirm that both lower body edges rest on the corner shelves, the lens/microphone face is unobstructed, and the webcam cannot slide forward, backward, or sideways.",
        "Let the attached USB lead leave straight through the completely open back of the green cradle. Curve it around either green side, then route it through either rounded 16 x 10 mm side window in the blue holder. Do not cut the blue back wall; leave separate loose service loops for tilt and pan.",
    ]
    assembly_numbers = new_numbering_instance(doc)
    for step in steps:
        add_number(doc, step, assembly_numbers)
    page_break(doc)
    add_heading(doc, "Assembly orientation", 1)
    add_body(
        doc,
        "The lower SG90 stands vertically on the full 140 mm circular base beneath the pan pad. Its wire exits through either 14 x 9 mm tower window and matching groove. The upper SG90 lies on its side inside the blue cage; its lead and the webcam cable exit through either rounded 16 x 10 mm side window, never through the back wall.",
    )
    add_picture(
        doc,
        RENDER_DIR / "01_Full_Assembly_With_Servos.png",
        5.05,
        "Complete assembly showing the lower vertical SG90 pan servo fastened to the stability base and the upper horizontal SG90 tilt servo.",
        "Figure 4. Neutral assembly orientation; the wide circular side-routing base supports the perpendicular pan and tilt axes.",
    )
    add_table(
        doc,
        ["Servo", "Shaft direction", "Motion"],
        [
            ("Pan SG90", "Vertical, +Z", "Turns the entire arm left/right"),
            ("Tilt SG90", "Horizontal, +Y", "Rotates the webcam down/up"),
        ],
        [1900, 2600, 4860],
    )

    page_break(doc)
    add_heading(doc, "4. Motion, cable routing, and controls", 1)
    add_picture(
        doc,
        RENDER_DIR / "03_Tilt_Range_Minus45_to_Plus45.png",
        4.75,
        "Overlay showing the webcam and green cradle at minus 45 degrees, neutral, and plus 45 degrees about the horizontal tilt axis.",
        "Figure 5. Intended tilt range from -45 to +45 degrees; transparent positions show the swept webcam envelope above the stability base.",
    )
    add_heading(doc, "Servo commands", 2)
    add_body(
        doc,
        "For a typical 0-180 degree servo command interface, use 90 degrees as neutral. Limit the tilt servo to approximately 45-135 degrees. Begin with slower motion and reduce acceleration until the webcam and cable remain stable.",
    )
    add_table(
        doc,
        ["Axis", "Neutral", "Recommended initial software limits", "Physical result"],
        [
            ("Pan", "90 degrees", "Choose limits after checking the base and cable", "Camera turns left/right around Z"),
            ("Tilt", "90 degrees", "45-135 degrees", "Camera moves down/up around Y"),
        ],
        [1150, 1300, 3370, 3540],
    )
    add_heading(doc, "USB cable service loop", 2)
    solidworks_numbers = new_numbering_instance(doc)
    for item in (
        "Let the webcam cable leave straight through the green cradle's completely open rear aperture, curve it around either side, and pass the upper cable bundle through either rounded 16 x 10 mm side window in the blue holder.",
        "Leave enough slack for both +45 and -45 degree tilt positions before securing the cable to the arm.",
        "Anchor the cable below the tilt servo with a loose strain-relief tie, leave another loop for pan rotation, and set software limits before the cable approaches one full wrap around the base.",
    ):
        add_bullet(doc, item)
    page_break(doc)
    add_heading(doc, "5. SolidWorks workflow", 1)
    add_heading(doc, "Open the provided STEP files", 2)
    for item in (
        "In SolidWorks, choose File > Open and select the desired .step file.",
        "Keep 3D Interconnect enabled when prompted. After the import completes, run Import Diagnostics if SolidWorks reports any face issues.",
        "Save each imported component as a new .SLDPRT. Do not overwrite your original Arm.SLDPRT or SG90 library model.",
        "Open C270_PanTilt_Full_Assembly_With_Servos.step for the positioned visual assembly, or C270_PanTilt_Printable_Assembly.step for only the four printable components.",
    ):
        add_number(doc, item, solidworks_numbers)
    add_heading(doc, "Recommended assembly mates", 2)
    add_table(
        doc,
        ["Mate", "Geometry", "Purpose"],
        [
            ("Concentric", "Pan servo shaft / pan-pad center", "Defines the vertical pan axis."),
            ("Coincident", "Pan horn face / underside of blue pad", "Seats the arm on the pan horn."),
            ("Concentric", "Tilt shaft / green cradle horn boss", "Defines the horizontal tilt axis."),
            ("Coincident", "Tilt horn face / green boss face", "Seats the camera cradle on the horn."),
            ("Limit angle", "Green cradle relative to blue arm", "Sets -45 to +45 degree tilt motion."),
        ],
        [1600, 3460, 4300],
    )
    add_heading(doc, "Reference-model warning", 2)
    add_body(
        doc,
        "The supplied User Library-SG90.sldprt was exported and measured at 32.5 x 30.1 x 12.5 mm overall, with mounting-ear slot centres 27.5 mm apart. The blue assembly proxy remains simplified for clarity. SG90 clones can still differ in side-cable exit and horn dimensions, so physically test-fit the plug, screws, and horn before the final long print.",
    )

    page_break(doc)
    add_heading(doc, "6. Verification", 1)
    add_heading(doc, "Completed CAD checks", 2)
    add_table(
        doc,
        ["Check", "Result", "Meaning"],
        [
            ("Printable STEP re-import", "PASS", "Each printable component is one valid solid."),
            ("Printable assembly", "PASS", "Assembly contains exactly four printable solids."),
            ("Full visual assembly", "PASS", "Contains 10 valid solids including two SG90 proxies and the C270 body/clip proxy."),
            ("Screwless C270 cradle", "PASS", "Full 74.11 mm rear-aperture blockage and fixed-clip collision are 0.0000 mm3. The 3.7699 mm3 body contact is the intentional 0.15 mm flexible side-grip preload."),
            ("Stability-base footprint", "PASS", "Full 140 mm circular footprint and 70 mm support radius are preserved."),
            ("Pan-servo side exits", "PASS", "Two 14 x 9 mm tower windows and two 14 mm-wide x 4 mm-deep side grooves; measured blockage is 0.0000 mm3."),
            ("Upper-holder side exits", "PASS", "Two rounded 16 x 10 mm side windows; left and right blockage are each 0.0000 mm3."),
            ("Supplied SG90 ear spacing", "PASS", "Measured at 27.5 mm centre-to-centre; base pilots corrected to the same spacing."),
            ("Printed screw paths", "PASS", "Base pilots, four holder pilots, four cap clearances, and all horn holes measure 0.0000 mm3 blockage."),
            ("Base / pan-servo collision", "0.0000 mm3", "Servo body and horn clear the gray plate and mounting towers."),
            ("Base / arm collision", "0.0000 mm3", "The arm and pan pad remain clear above the servo/base mount."),
            ("Pan servo/body collision", "0.0000 mm3", "Raised pan pad and trimmed upright clear the servo and horn."),
            ("Tilt servo/body collision", "0.0000 mm3", "Servo proxy clears the blue cage and orange cap."),
            ("Arm curve construction", "PASS", "Exact circular/spline geometry; no segmented sketch ridge."),
            ("Tilt envelope", "PASS", "Modeled at -45, 0, and +45 degrees with cable side kept open."),
        ],
        [3300, 1700, 4360],
    )
    page_break(doc)
    add_heading(doc, "7. Package map and final checklist", 1)
    add_heading(doc, "Folder structure", 2)
    for item in (
        "Printable_Parts - individual STEP and STL files for the gray stability base, blue arm, orange cap, and green camera cradle.",
        "Assemblies - a printable-only STEP assembly and a full STEP assembly with two servo proxies and a webcam proxy.",
        "Reference_Models - separate visual-reference STEP files for a generic SG90 and Logitech C270 envelope.",
        "Renders - full assembly, exploded parts, tilt range, pan-base detail, upper side-exit detail, and screwless-cradle detail PNG illustrations.",
        "Documentation - this Word guide, the dedicated 3D printing guide, README_Robotic_Arm_RevI.txt, and verification report.",
    ):
        add_bullet(doc, item)
    add_heading(doc, "Final pre-power checklist", 2)
    for item in (
        "Both servos are centered before their horns are installed.",
        "The pan servo is secured to both gray mounting towers, or retained through the backup strap slots.",
        "The pan-servo plug passes freely through a gray side-tower window and its lead lies in the matching side groove.",
        "The pan upright clears the horn and base through the complete commanded pan range.",
        "The tilt servo cannot slide in its cage, but the cap is not overtightened.",
        "The C270 body rests on both green corner shelves, both shallow side-grip ribs contact it lightly, the flexible top lips retain it, and its fixed monitor clip hangs freely through the open underside.",
        "No screw enters or presses against the webcam; the only camera-side screw fastens the green cradle to the SG90 horn.",
        "The complete back of the webcam is exposed across the green cradle's 74.11 mm inner width, and the attached USB cable leaves straight backward before curving toward a blue side window.",
        "The upper cable bundle exits through a blue 16 x 10 mm side window, not through the back, and separate service loops for tilt and pan cannot snag.",
        "Software starts with conservative speed, acceleration, and angle limits.",
    ):
        add_bullet(doc, item)
    add_callout(
        doc,
        "READY FOR TESTING",
        "Run the first powered test without fast tracking code: command neutral, then small pan and tilt movements, then gradually expand to the verified limits while watching the cable and servo temperature.",
    )

    doc.core_properties.title = "C270 Pan-Tilt Robotic Arm - Complete Build Guide"
    doc.core_properties.subject = "Revision I SolidWorks, fully open-back screwless C270 cradle, side-exit arm wiring, measured SG90 screw spacing, printing, and verification documentation"
    doc.core_properties.author = "Codex"
    doc.core_properties.keywords = "Logitech C270, SG90, pan tilt, SolidWorks, robotic arm"
    doc.core_properties.comments = "Generated from the validated Revision I CAD package with a fully open-back screwless C270 cradle, flexible side grips, side-only blue-arm exits, and verified clearances."
    DOC_DIR.mkdir(parents=True, exist_ok=True)
    doc.save(OUT)
    print(OUT)


if __name__ == "__main__":
    build()
