C270 ROBOTIC ARM - REVISION E
================================

Architecture
- Pan axis: Z (vertical), through the 40 mm bottom horn pad.
- Tilt axis: Y (horizontal), at Z = 94 mm.
- Axis relationship: exactly 90 degrees.
- Intended software tilt limit: -45 to +45 degrees.
- Curved-arm edges: exact analytic arcs with a 1 mm edge round; no segmented sketch ridges.

Input dimensions
- C270 envelope: 72.91 x 31.91 x 66.64 mm.
- C270 mass: 75 g.
- Curved arm: R50, 14 mm wide, 6 mm thick, 80 mm centres.

Generated-part bounding boxes (X x Y x Z)
- Arm/holder: 47.00 x 44.00 x 104.00 mm.
- Servo cap: 31.00 x 3.00 x 24.00 mm.
- Camera cradle: 80.00 x 12.00 x 42.50 mm.
- Pan-servo stability base: 140.00 x 140.04 x 18.60 mm.
- Stability footprint: 140 mm diameter (70 mm radius in every pan direction).
- Pan-servo side ports: two openings, each 14 x 9 mm, feeding 14 mm-wide side grooves.
- Arm cable loop: rounded 20 x 10 mm through-opening behind the tilt-servo cable exit.

Conservative webcam-envelope clearance to the fixed arm/holder
- At -45 degrees: 13.00 mm.
- At +0 degrees: 13.00 mm.
- At +45 degrees: 13.00 mm.

Static load estimate using a 39.9 mm combined depth/height lever: 0.299 kg-cm.
This excludes acceleration, cable pull, and impact loads.

Fit and assembly notes
1. Import STEP files into SolidWorks with 3D Interconnect enabled, then save as SLDPRT.
2. Seat the pan SG90 upright on the stability base with its shaft pointing +Z; fasten its ears to the two M2 pilot holes.
3. Point the pan-servo wire toward either gray side tower, pass its plug through the 14 x 9 mm side window, and lay the lead in that side's 14 mm-wide groove.
4. Insert the tilt SG90 from the +Y/front side with its shaft pointing +Y.
5. Secure the cap with four M2 self-tapping screws. Use a thin foam shim if your SG90 clone is loose.
6. Attach the camera cradle to the actual SG90 horn using the adaptable 3.2 mm centre and 2.0 mm pilot-hole pattern.
7. Pass the tilt-servo lead and webcam cable through the blue arm's rounded 20 x 10 mm cable loop, then clamp the C270's fixed monitor clip over the cradle's 5 mm top blade. The right-side notch is the USB-cable exit.
8. Set the servo neutral before installing the horn; enforce 45..135 degrees in software for a +/-45 degree tilt range.
9. The four outer base holes can fasten the assembly to a board or accept rubber-foot hardware for additional stability.
10. The included SG90 and C270 reference STEP models are visual proxies; compare the supplied SG90 model and physical hardware before final printing.

Printing suggestion
- PETG or PLA+, 0.20 mm layers, 4 perimeters, 35-45% infill.
- Print the 140 mm stability base flat with its circular plate on the bed; keep both tower windows and side grooves clear of support.
- Print the arm on a broad curved side, the cap on its 31 x 24 mm face, and the camera cradle on its long bottom edge with a brim.

Package map
- Printable_Parts: four individual STEP/STL printable components, including PanServo_StabilityBase.
- Assemblies: printable assembly and a full visual assembly with two SG90 servos and a C270 proxy.
- Reference_Models: generic SG90 and C270 visualization STEP files.
- Documentation: illustrated build/printing guides, verification report, and this README.
- Renders: neutral assembly, exploded parts, tilt range, and pan-base detail illustrations.
- Source: parametric CAD generator used to create Revision E.
- Verification_Report.txt: STEP re-import, single-solid, curve, and collision results.