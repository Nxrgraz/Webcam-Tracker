"""Generate Revision G of the SolidWorks-ready C270 pan/tilt arm.

Units are millimetres.  The STEP files are the preferred SolidWorks imports;
STL files are supplied for printing and quick visual checks.  Revision G keeps
the verified Revision F arm, base, and servo cap unchanged, and replaces the
webcam clip blade with a one-piece screwless basket cradle for the C270 body.
"""

from __future__ import annotations

import math
from pathlib import Path

import cadquery as cq
from cadquery import exporters


OUT = Path(r"C:\Users\zongs\Documents\Codex\2026-08-20\can-y\outputs\C270_Robotic_Arm_RevG")
WORK = Path(r"C:\Users\zongs\Documents\Codex\2026-08-20\can-y\work")
OUT.mkdir(parents=True, exist_ok=True)
PRINT_DIR = OUT / "Printable_Parts"
REF_DIR = OUT / "Reference_Models"
ASM_DIR = OUT / "Assemblies"
DOC_DIR = OUT / "Documentation"
RENDER_DIR = OUT / "Renders"
for directory in (PRINT_DIR, REF_DIR, ASM_DIR, DOC_DIR, RENDER_DIR):
    directory.mkdir(parents=True, exist_ok=True)

# Core arm dimensions from the user's sketch.
ARM_CENTER_SPACING = 80.0
ARM_CENTERLINE_RADIUS = 50.0
ARM_WIDTH = 14.0
ARM_THICKNESS = 6.0
BOSS_DIAMETER = 28.0
PAN_PAD_DIAMETER = 40.0
PAN_PAD_THICKNESS = 4.0

# Common SG90 envelope plus print clearance.  The open flange slots tolerate
# small clone-to-clone differences and let the supplied servo model be checked
# after STEP import.
SERVO_BODY_X = 22.8
SERVO_BODY_Y = 12.2
SERVO_CLEARANCE = 0.8
TILT_AXIS_Z = 94.0

# Logitech C270 bounding data supplied by the user.
C270_WIDTH = 72.91
C270_HEIGHT = 31.91
C270_DEPTH_WITH_CLIP = 66.64
C270_MASS_G = 75.0

# Revision G screwless webcam cradle.  The basket holds the webcam body at its
# lower corners, sides, back, and top corners while leaving the lens/front and
# the middle underside open for the C270's permanently attached monitor clip.
# The right wall includes an oversized cable relief.  No screw touches the
# webcam; the only screw interface is between this printed cradle and the SG90
# horn.
CRADLE_BODY_DEPTH = 22.0
CRADLE_FIT_CLEARANCE = 0.60
CRADLE_WALL = 2.80
CRADLE_FRONT_Y = 9.0 - CRADLE_FIT_CLEARANCE
CRADLE_BACK_Y = 9.0 + CRADLE_BODY_DEPTH + CRADLE_FIT_CLEARANCE
CRADLE_BOTTOM_Z = 6.0 - CRADLE_FIT_CLEARANCE
CRADLE_TOP_Z = 6.0 + C270_HEIGHT + CRADLE_FIT_CLEARANCE
CRADLE_INNER_HALF_X = C270_WIDTH / 2.0 + CRADLE_FIT_CLEARANCE
CRADLE_OUTER_HALF_X = CRADLE_INNER_HALF_X + CRADLE_WALL
CRADLE_CABLE_WINDOW_Y = 16.0
CRADLE_CABLE_WINDOW_Z = 14.0

# Revision F preserves the Revision E pan-servo stability base.  The 140 mm circular footprint is
# uniform in every pan direction and fits common 220 x 220 mm FDM beds.
BASE_DIAMETER = 140.0
BASE_THICKNESS = 6.0
BASE_BOTTOM_Z = -27.0
BASE_TOP_Z = BASE_BOTTOM_Z + BASE_THICKNESS
BASE_MOUNT_RADIUS = 50.0
BASE_SIDE_PORT_WIDTH = 14.0
BASE_SIDE_PORT_HEIGHT = 9.0
BASE_SIDE_GROOVE_WIDTH = 14.0
BASE_SIDE_GROOVE_DEPTH = 4.0
ARM_SIDE_PORT_LENGTH = 16.0
ARM_SIDE_PORT_HEIGHT = 10.0
ARM_SIDE_PORT_CENTER_Y = 10.5

# Verified printed fastener patterns.  The base holes match the 27.5 mm
# centre-to-centre ear-slot pattern measured from User Library-SG90.sldprt.
SG90_EAR_HOLE_SPACING = 27.5
SG90_EAR_PILOT_DIAMETER = 1.9
CAP_SCREW_CENTER_X = 13.85
CAP_SCREW_CENTER_Z_OFFSET = 7.5
CAP_PILOT_DIAMETER = 1.8
CAP_CLEARANCE_DIAMETER = 2.4
HORN_CENTER_CLEARANCE_DIAMETER = 3.2
HORN_PILOT_DIAMETER = 2.0
HORN_PILOT_RADIUS = 7.0


def box_at(x1: float, x2: float, y1: float, y2: float, z1: float, z2: float) -> cq.Workplane:
    """Axis-aligned box from minima/maxima."""
    return (
        cq.Workplane("XY")
        .box(x2 - x1, y2 - y1, z2 - z1, centered=(True, True, False))
        .translate(((x1 + x2) / 2.0, (y1 + y2) / 2.0, z1))
    )


def cyl_y(radius: float, y1: float, y2: float, x: float, z: float) -> cq.Workplane:
    solid = cq.Solid.makeCylinder(
        radius,
        y2 - y1,
        cq.Vector(x, y1, z),
        cq.Vector(0, 1, 0),
    )
    return cq.Workplane(obj=solid)


def cyl_x(radius: float, x1: float, x2: float, y: float, z: float) -> cq.Workplane:
    solid = cq.Solid.makeCylinder(
        radius,
        x2 - x1,
        cq.Vector(x1, y, z),
        cq.Vector(1, 0, 0),
    )
    return cq.Workplane(obj=solid)


def cyl_z(radius: float, z1: float, z2: float, x: float = 0.0, y: float = 0.0) -> cq.Workplane:
    solid = cq.Solid.makeCylinder(
        radius,
        z2 - z1,
        cq.Vector(x, y, z1),
        cq.Vector(0, 0, 1),
    )
    return cq.Workplane(obj=solid)


def side_capsule_x(
    x1: float,
    x2: float,
    y_center: float,
    length: float,
    height: float,
    z_center: float,
) -> cq.Workplane:
    """Rounded cable window in a YZ side face, extruded along X."""
    radius = height / 2.0
    half_span = (length - height) / 2.0
    opening = box_at(
        x1,
        x2,
        y_center - half_span,
        y_center + half_span,
        z_center - radius,
        z_center + radius,
    )
    opening = opening.union(cyl_x(radius, x1, x2, y_center - half_span, z_center))
    opening = opening.union(cyl_x(radius, x1, x2, y_center + half_span, z_center))
    return opening.clean()


def arm_ribbon() -> cq.Workplane:
    """Curved 14 mm ribbon using exact analytic arcs, not segmented lines."""
    bottom_z = 14.0
    arc_cx = 30.0
    arc_cz = bottom_z + ARM_CENTER_SPACING / 2.0
    outer_r = ARM_CENTERLINE_RADIUS + ARM_WIDTH / 2.0
    inner_r = ARM_CENTERLINE_RADIUS - ARM_WIDTH / 2.0
    start_deg = math.degrees(math.atan2(bottom_z - arc_cz, -arc_cx))
    end_deg = start_deg - math.degrees(
        2.0 * math.asin(ARM_CENTER_SPACING / (2.0 * ARM_CENTERLINE_RADIUS))
    )

    mid_deg = (start_deg + end_deg) / 2.0

    def point(radius: float, angle_deg: float) -> tuple[float, float]:
        angle = math.radians(angle_deg)
        return (arc_cx + radius * math.cos(angle), arc_cz + radius * math.sin(angle))

    outer_start = point(outer_r, start_deg)
    outer_mid = point(outer_r, mid_deg)
    outer_end = point(outer_r, end_deg)
    inner_end = point(inner_r, end_deg)
    inner_mid = point(inner_r, mid_deg)
    inner_start = point(inner_r, start_deg)

    ribbon = (
        cq.Workplane("XZ")
        .moveTo(*outer_start)
        .threePointArc(outer_mid, outer_end)
        .lineTo(*inner_end)
        .threePointArc(inner_mid, inner_start)
        .close()
        .extrude(ARM_THICKNESS / 2.0, both=True)
    )
    bottom_boss = (
        cq.Workplane("XZ")
        .center(0, bottom_z)
        .circle(BOSS_DIAMETER / 2.0)
        .extrude(ARM_THICKNESS / 2.0, both=True)
    )
    top_boss = (
        cq.Workplane("XZ")
        .center(0, bottom_z + ARM_CENTER_SPACING)
        .circle(BOSS_DIAMETER / 2.0)
        .extrude(ARM_THICKNESS / 2.0, both=True)
    )
    smooth_arm = ribbon.union(bottom_boss).union(top_boss).clean()
    # Round the two broad-profile edges to remove the hard ridge and improve grip/appearance.
    try:
        smooth_arm = smooth_arm.edges("|Y").fillet(1.0)
    except Exception:
        # The exact arcs remain smooth even if a kernel build rejects a cosmetic fillet.
        pass
    return smooth_arm


def make_arm_and_holder() -> cq.Workplane:
    # Horizontal pan-horn pad: pan axis is Z; tilt axis is Y, exactly 90 degrees apart.
    # The pad starts at Z=4 mm, leaving room below it for the SG90 horn.
    pad = (
        cq.Workplane("XY")
        .circle(PAN_PAD_DIAMETER / 2.0)
        .extrude(PAN_PAD_THICKNESS)
        .translate((0, 0, 4.0))
    )
    pad = pad.edges("%CIRCLE").fillet(1.0)
    pad = pad.cut(cyl_z(HORN_CENTER_CLEARANCE_DIAMETER / 2.0, 3.5, 8.5))
    for x, y in (
        (HORN_PILOT_RADIUS, 0),
        (-HORN_PILOT_RADIUS, 0),
        (0, HORN_PILOT_RADIUS),
        (0, -HORN_PILOT_RADIUS),
    ):
        pad = pad.cut(cyl_z(HORN_PILOT_DIAMETER / 2.0, 3.5, 8.5, x, y))

    # Trim the vertical profile at the pan-pad interface; it no longer protrudes into the horn.
    upright = arm_ribbon().intersect(box_at(-100, 100, -100, 100, 7.5, 200.0))
    arm = pad.union(upright)

    # Compact sideways SG90 cage.  Servo slides in from +Y; output shaft points +Y.
    holder = box_at(-17.0, 17.0, 2.5, 6.0, 84.0, 104.0)  # back
    holder = holder.union(box_at(-15.5, 15.5, 2.5, 24.0, 84.0, 87.0))  # lower rail
    holder = holder.union(box_at(-15.5, -12.2, 2.5, 24.0, 84.0, 104.0))
    holder = holder.union(box_at(12.2, 15.5, 2.5, 24.0, 84.0, 104.0))
    holder = holder.union(box_at(-15.5, 15.5, 2.5, 24.0, 101.0, 104.0))

    # Openings for the standard SG90 mounting ears near the output end.
    holder = holder.cut(box_at(-17.0, -12.0, 18.0, 24.5, 87.0, 101.0))
    holder = holder.cut(box_at(12.0, 17.0, 18.0, 24.5, 87.0, 101.0))

    # Four cap pilot holes, axis Y.  They accept M2 self-tapping screws.
    for x in (-CAP_SCREW_CENTER_X, CAP_SCREW_CENTER_X):
        for z in (TILT_AXIS_Z - CAP_SCREW_CENTER_Z_OFFSET, TILT_AXIS_Z + CAP_SCREW_CENTER_Z_OFFSET):
            holder = holder.cut(cyl_y(CAP_PILOT_DIAMETER / 2.0, 1.5, 24.5, x, z))

    combined = arm.union(holder).clean()

    # Two rounded side-entry windows replace the incorrect rear-facing loop.
    # Either window passes a typical three-pin SG90 plug or USB-A plug while
    # leaving the central back wall intact.  The cable then runs down the
    # outside face of the curved arm with a loose service loop.
    left_port = side_capsule_x(
        -17.5,
        -11.5,
        ARM_SIDE_PORT_CENTER_Y,
        ARM_SIDE_PORT_LENGTH,
        ARM_SIDE_PORT_HEIGHT,
        TILT_AXIS_Z,
    )
    right_port = side_capsule_x(
        11.5,
        17.5,
        ARM_SIDE_PORT_CENTER_Y,
        ARM_SIDE_PORT_LENGTH,
        ARM_SIDE_PORT_HEIGHT,
        TILT_AXIS_Z,
    )
    combined = combined.cut(left_port).cut(right_port)

    # Re-cut every screw path after all unions.  This prevents the curved-arm
    # bosses from partially filling holes that were drilled in the pad or cage
    # before those solids were joined.
    combined = combined.cut(
        cyl_z(HORN_CENTER_CLEARANCE_DIAMETER / 2.0, 3.5, 8.5)
    )
    for x, y in (
        (HORN_PILOT_RADIUS, 0),
        (-HORN_PILOT_RADIUS, 0),
        (0, HORN_PILOT_RADIUS),
        (0, -HORN_PILOT_RADIUS),
    ):
        combined = combined.cut(
            cyl_z(HORN_PILOT_DIAMETER / 2.0, 3.5, 8.5, x, y)
        )
    for x in (-CAP_SCREW_CENTER_X, CAP_SCREW_CENTER_X):
        for z in (
            TILT_AXIS_Z - CAP_SCREW_CENTER_Z_OFFSET,
            TILT_AXIS_Z + CAP_SCREW_CENTER_Z_OFFSET,
        ):
            combined = combined.cut(
                cyl_y(CAP_PILOT_DIAMETER / 2.0, 1.5, 24.5, x, z)
            )
    return combined.clean()


def make_servo_cap() -> cq.Workplane:
    cap = box_at(-15.5, 15.5, 24.0, 27.0, 82.0, 106.0)
    # Round output/horn clearance leaves the central servo face visible.
    cap = cap.cut(cyl_y(10.5, 23.5, 27.5, 0.0, TILT_AXIS_Z))
    for x in (-CAP_SCREW_CENTER_X, CAP_SCREW_CENTER_X):
        for z in (TILT_AXIS_Z - CAP_SCREW_CENTER_Z_OFFSET, TILT_AXIS_Z + CAP_SCREW_CENTER_Z_OFFSET):
            cap = cap.cut(cyl_y(CAP_CLEARANCE_DIAMETER / 2.0, 23.5, 27.5, x, z))
    return cap.clean()


def make_camera_screwless_cradle() -> cq.Workplane:
    """One-piece basket that captures the C270 without screwing into it.

    The camera lowers into the open-front basket.  Corner shelves carry the
    body but leave the permanent monitor clip free in the large centre opening.
    Thin top and front corner lips prevent the webcam from escaping; the side
    walls can flex slightly during insertion.  A rear rail controls fore/aft
    motion, and the right-side window clears the permanently attached USB lead.
    """
    # Horn boss and stiff mounting web live below the webcam, keeping the lens
    # face completely open.
    mount_web = box_at(
        -CRADLE_OUTER_HALF_X,
        CRADLE_OUTER_HALF_X,
        4.0,
        CRADLE_FRONT_Y,
        -24.0,
        CRADLE_BOTTOM_Z,
    )
    try:
        mount_web = mount_web.edges("|Y").fillet(2.0)
    except Exception:
        pass
    horn_boss = cyl_y(12.5, 0.0, 4.5, 0.0, 0.0)
    cradle = mount_web.union(horn_boss)

    # Two corner shelves support the webcam body.  The 62 mm-wide centre gap
    # remains open for the fixed monitor clip, so no clip geometry is forced.
    shelf_inner_x = 31.0
    shelf_y_back = CRADLE_BACK_Y + CRADLE_WALL
    cradle = cradle.union(
        box_at(
            -CRADLE_OUTER_HALF_X,
            -shelf_inner_x,
            CRADLE_FRONT_Y,
            shelf_y_back,
            CRADLE_BOTTOM_Z - CRADLE_WALL,
            CRADLE_BOTTOM_Z,
        )
    )
    cradle = cradle.union(
        box_at(
            shelf_inner_x,
            CRADLE_OUTER_HALF_X,
            CRADLE_FRONT_Y,
            shelf_y_back,
            CRADLE_BOTTOM_Z - CRADLE_WALL,
            CRADLE_BOTTOM_Z,
        )
    )

    # Full-height side cheeks define the width.  The back rail starts above the
    # fixed-clip envelope, while still supporting almost the complete body.
    cradle = cradle.union(
        box_at(
            -CRADLE_OUTER_HALF_X,
            -CRADLE_INNER_HALF_X,
            CRADLE_FRONT_Y,
            shelf_y_back,
            CRADLE_BOTTOM_Z - CRADLE_WALL,
            CRADLE_TOP_Z + CRADLE_WALL,
        )
    )
    cradle = cradle.union(
        box_at(
            CRADLE_INNER_HALF_X,
            CRADLE_OUTER_HALF_X,
            CRADLE_FRONT_Y,
            shelf_y_back,
            CRADLE_BOTTOM_Z - CRADLE_WALL,
            CRADLE_TOP_Z + CRADLE_WALL,
        )
    )
    cradle = cradle.union(
        box_at(
            -CRADLE_OUTER_HALF_X,
            CRADLE_OUTER_HALF_X,
            CRADLE_BACK_Y,
            shelf_y_back,
            8.7,
            CRADLE_TOP_Z + CRADLE_WALL,
        )
    )

    # Small front and top corner returns turn the structure into a cradle, not
    # a flat blade.  They overlap only the outer body corners so the lens and
    # microphone area remain unobstructed.
    corner_inner_x = C270_WIDTH / 2.0 - 2.0
    for x0, x1 in (
        (-CRADLE_OUTER_HALF_X, -corner_inner_x),
        (corner_inner_x, CRADLE_OUTER_HALF_X),
    ):
        cradle = cradle.union(
            box_at(
                x0,
                x1,
                CRADLE_FRONT_Y - 2.0,
                CRADLE_FRONT_Y,
                CRADLE_BOTTOM_Z,
                CRADLE_TOP_Z + CRADLE_WALL,
            )
        )
        cradle = cradle.union(
            box_at(
                x0,
                x1,
                CRADLE_FRONT_Y,
                shelf_y_back,
                CRADLE_TOP_Z,
                CRADLE_TOP_Z + CRADLE_WALL,
            )
        )

    # Large right-side cable window.  It is deliberately bigger than a bare
    # cable so the molded C270 strain relief can move through the tilt range.
    cradle = cradle.cut(
        side_capsule_x(
            CRADLE_INNER_HALF_X - 0.5,
            CRADLE_OUTER_HALF_X + 0.5,
            24.0,
            CRADLE_CABLE_WINDOW_Y,
            CRADLE_CABLE_WINDOW_Z,
            18.0,
        )
    )

    # Horn attachment pattern: the screws fasten the printed cradle to the
    # supplied SG90 horn.  They never enter or touch the webcam.
    cradle = cradle.cut(cyl_y(HORN_CENTER_CLEARANCE_DIAMETER / 2.0, -0.5, 9.5, 0.0, 0.0))
    for x, z in (
        (HORN_PILOT_RADIUS, 0),
        (-HORN_PILOT_RADIUS, 0),
        (0, HORN_PILOT_RADIUS),
        (0, -HORN_PILOT_RADIUS),
    ):
        cradle = cradle.cut(cyl_y(HORN_PILOT_DIAMETER / 2.0, -0.5, 9.5, x, z))

    return cradle.clean()


def make_pan_servo_stability_base() -> cq.Workplane:
    """Wide, low base that supports and fastens the upright pan SG90.

    The SG90 reference body rests on the plate at Z=-21 mm.  Two side towers
    sit clear of the body and support its mounting ears.  Pilot holes accept
    common M2 servo screws, while the outer M4 holes can fasten the base to a
    board or accept rubber-foot hardware.  Strap slots provide a clone-tolerant
    fallback when ear-hole spacing differs.
    """
    base = (
        cq.Workplane("XY")
        .circle(BASE_DIAMETER / 2.0)
        .extrude(BASE_THICKNESS)
        .translate((0, 0, BASE_BOTTOM_Z))
    )
    try:
        base = base.edges("%CIRCLE").fillet(1.8)
    except Exception:
        pass

    # Upright supports and ledges for the two horizontal SG90 mounting ears.
    left_tower = box_at(-18.5, -12.2, -8.5, 8.5, BASE_TOP_Z, -8.4)
    right_tower = box_at(12.2, 18.5, -8.5, 8.5, BASE_TOP_Z, -8.4)
    left_ledge = box_at(-19.0, -11.8, -10.5, 10.5, -10.6, -8.4)
    right_ledge = box_at(11.8, 19.0, -10.5, 10.5, -10.6, -8.4)
    base = base.union(left_tower).union(right_tower).union(left_ledge).union(right_ledge)

    # Large side windows align with either possible SG90 cable-exit side.  The
    # connector can pass through before the servo ears are screwed down.
    port_y = BASE_SIDE_PORT_WIDTH / 2.0
    port_z1 = -20.0
    port_z2 = port_z1 + BASE_SIDE_PORT_HEIGHT
    base = base.cut(box_at(-19.5, -11.5, -port_y, port_y, port_z1, port_z2))
    base = base.cut(box_at(11.5, 19.5, -port_y, port_y, port_z1, port_z2))

    # Shallow left/right grooves continue each side window to the plate edge.
    # A 2 mm floor remains under the 4 mm-deep cable recess.
    groove_y = BASE_SIDE_GROOVE_WIDTH / 2.0
    groove_z1 = BASE_TOP_Z - BASE_SIDE_GROOVE_DEPTH
    base = base.cut(box_at(-71.0, -18.0, -groove_y, groove_y, groove_z1, BASE_TOP_Z + 0.5))
    base = base.cut(box_at(18.0, 71.0, -groove_y, groove_y, groove_z1, BASE_TOP_Z + 0.5))

    # M2 self-tapping pilot holes beneath the standard SG90 ear locations.
    for x in (-SG90_EAR_HOLE_SPACING / 2.0, SG90_EAR_HOLE_SPACING / 2.0):
        base = base.cut(cyl_z(SG90_EAR_PILOT_DIAMETER / 2.0, -15.0, -7.8, x, 0.0))

    # Two through-slots let a narrow zip tie retain unusually shaped SG90 clones.
    base = base.cut(box_at(-24.5, -21.5, -8.0, 8.0, BASE_BOTTOM_Z - 0.5, BASE_TOP_Z + 0.5))
    base = base.cut(box_at(21.5, 24.5, -8.0, 8.0, BASE_BOTTOM_Z - 0.5, BASE_TOP_Z + 0.5))

    # Four M4-class table/board mounting holes with shallow top counterbores.
    offset = BASE_MOUNT_RADIUS / math.sqrt(2.0)
    for x in (-offset, offset):
        for y in (-offset, offset):
            base = base.cut(cyl_z(2.2, BASE_BOTTOM_Z - 0.5, BASE_TOP_Z + 0.5, x, y))
            base = base.cut(cyl_z(4.2, -23.2, BASE_TOP_Z + 0.5, x, y))

    return base.clean()


def make_sg90_reference() -> tuple[cq.Workplane, cq.Workplane]:
    """A dimensionally representative SG90 body and horn for assembly visualization."""
    # Upright reference: output axis is +Z at the origin; body extends downward.
    body = box_at(-11.4, 11.4, -6.1, 6.1, -21.0, -4.0)
    body = body.union(box_at(-16.2, 16.2, -6.1, 6.1, -8.0, -5.8))
    body = body.union(cyl_z(6.0, -4.0, -0.7, 0.0, 0.0))
    body = body.union(cyl_z(4.0, -4.0, -0.7, 6.0, 0.0))
    body = body.union(cyl_z(2.35, -0.7, 2.0, 0.0, 0.0))
    for x in (-SG90_EAR_HOLE_SPACING / 2.0, SG90_EAR_HOLE_SPACING / 2.0):
        body = body.cut(cyl_z(1.1, -8.5, -5.3, x, 0.0))
    try:
        body = body.edges("|Z").fillet(0.8)
    except Exception:
        pass

    # Cross horn is a separate reference solid so it can be colored white.
    horn = cyl_z(4.8, 2.0, 3.8)
    horn = horn.union(box_at(-16.0, 16.0, -2.0, 2.0, 2.4, 3.8))
    horn = horn.union(box_at(-2.0, 2.0, -11.0, 11.0, 2.4, 3.8))
    horn = horn.cut(cyl_z(1.0, 1.8, 4.0))
    return body.clean(), horn.clean()


def make_c270_reference() -> tuple[cq.Workplane, cq.Workplane]:
    """A simplified C270 body and fixed-clip envelope for assembly visualization."""
    # Local tilt axis is Y through (0,0,0). The clip blade top is Z=6 mm.
    webcam = box_at(-C270_WIDTH / 2, C270_WIDTH / 2, 9.0, 31.0, 6.0, 6.0 + C270_HEIGHT)
    try:
        webcam = webcam.edges("|Y").fillet(7.0)
    except Exception:
        pass
    lens = cyl_y(7.0, 5.0, 9.2, -10.0, 6.0 + C270_HEIGHT * 0.58)
    lens = lens.union(cyl_y(3.8, 3.8, 5.2, -10.0, 6.0 + C270_HEIGHT * 0.58))
    webcam = webcam.union(lens).clean()

    # The clip is deliberately simplified but uses the complete supplied depth envelope.
    clip = box_at(-30.0, 30.0, 18.0, 18.0 + C270_DEPTH_WITH_CLIP - 22.0, -4.0, 8.0)
    try:
        clip = clip.edges("|Y").fillet(3.0)
    except Exception:
        pass
    return webcam, clip.clean()


def positioned_reference_models() -> dict[str, cq.Workplane]:
    servo_body, servo_horn = make_sg90_reference()
    pan_body = servo_body
    pan_horn = servo_horn
    tilt_body = servo_body.rotate((0, 0, 0), (1, 0, 0), -90.0).translate((0, 27.0, TILT_AXIS_Z))
    tilt_horn = servo_horn.rotate((0, 0, 0), (1, 0, 0), -90.0).translate((0, 27.0, TILT_AXIS_Z))
    webcam, clip = make_c270_reference()
    webcam = webcam.translate((0, 31.0, TILT_AXIS_Z))
    clip = clip.translate((0, 31.0, TILT_AXIS_Z))
    return {
        "SG90_Pan_Body": pan_body,
        "SG90_Pan_Horn": pan_horn,
        "SG90_Tilt_Body": tilt_body,
        "SG90_Tilt_Horn": tilt_horn,
        "C270_Webcam_Body": webcam,
        "C270_Fixed_Clip": clip,
    }


def export_part(shape: cq.Workplane, stem: str) -> None:
    exporters.export(shape, str(PRINT_DIR / f"{stem}.step"))
    exporters.export(
        shape,
        str(PRINT_DIR / f"{stem}.stl"),
        tolerance=0.03,
        angularTolerance=0.04,
    )


def export_reference_models() -> None:
    servo_body, servo_horn = make_sg90_reference()
    servo_assembly = cq.Assembly(name="SG90_Visual_Reference")
    servo_assembly.add(servo_body, name="SG90_Body", color=cq.Color(0.12, 0.35, 0.78))
    servo_assembly.add(servo_horn, name="SG90_Cross_Horn", color=cq.Color(0.95, 0.95, 0.92))
    servo_assembly.save(str(REF_DIR / "SG90_Visual_Reference.step"))

    webcam, clip = make_c270_reference()
    webcam_assembly = cq.Assembly(name="Logitech_C270_Visual_Reference")
    webcam_assembly.add(webcam, name="C270_Body", color=cq.Color(0.08, 0.09, 0.11))
    webcam_assembly.add(clip, name="C270_Fixed_Clip", color=cq.Color(0.18, 0.19, 0.22))
    webcam_assembly.save(str(REF_DIR / "Logitech_C270_Visual_Reference.step"))


def export_positioned_assemblies(
    arm: cq.Workplane, cap: cq.Workplane, camera: cq.Workplane, base: cq.Workplane
) -> None:
    printable = cq.Assembly(name="C270_PanTilt_Printable_Assembly")
    printable.add(base, name="PanServo_StabilityBase", color=cq.Color(0.28, 0.31, 0.36))
    printable.add(arm, name="CurvedArm_SG90_TiltHolder", color=cq.Color(0.18, 0.55, 0.92))
    printable.add(cap, name="SG90_RetainingCap", color=cq.Color(0.95, 0.62, 0.18))
    printable.add(
        camera,
        name="Logitech_C270_ScrewlessCradle",
        loc=cq.Location(cq.Vector(0, 31.0, TILT_AXIS_Z)),
        color=cq.Color(0.18, 0.82, 0.58),
    )
    printable.save(str(ASM_DIR / "C270_PanTilt_Printable_Assembly.step"))

    assembly = cq.Assembly(name="C270_PanTilt_Full_Assembly_With_Servos")
    assembly.add(base, name="PanServo_StabilityBase", color=cq.Color(0.28, 0.31, 0.36))
    assembly.add(arm, name="CurvedArm_SG90_TiltHolder", color=cq.Color(0.18, 0.55, 0.92))
    assembly.add(cap, name="SG90_RetainingCap", color=cq.Color(0.95, 0.62, 0.18))
    assembly.add(
        camera,
        name="Logitech_C270_ScrewlessCradle",
        loc=cq.Location(cq.Vector(0, 31.0, TILT_AXIS_Z)),
        color=cq.Color(0.18, 0.82, 0.58),
    )
    refs = positioned_reference_models()
    for name, shape in refs.items():
        if "Horn" in name:
            color = cq.Color(0.95, 0.95, 0.92)
        elif "SG90" in name:
            color = cq.Color(0.12, 0.35, 0.78)
        elif "Webcam" in name:
            color = cq.Color(0.07, 0.08, 0.10)
        else:
            color = cq.Color(0.18, 0.19, 0.22)
        assembly.add(shape, name=name, color=color)
    assembly.save(str(ASM_DIR / "C270_PanTilt_Full_Assembly_With_Servos.step"))


def write_report(
    arm: cq.Workplane,
    cap: cq.Workplane,
    camera: cq.Workplane,
    base: cq.Workplane,
) -> None:
    camera_shift_y = 31.0
    webcam_envelope = box_at(
        -C270_WIDTH / 2,
        C270_WIDTH / 2,
        9.0,
        9.0 + C270_DEPTH_WITH_CLIP,
        6.0,
        6.0 + C270_HEIGHT,
    )

    fixed = cq.Compound.makeCompound([arm.val(), cap.val(), base.val()])
    clearances = []
    for angle in (-45.0, 0.0, 45.0):
        env = webcam_envelope.rotate((0, 0, 0), (0, 1, 0), angle).translate(
            (0, camera_shift_y, TILT_AXIS_Z)
        )
        distance = fixed.distance(env.val())
        clearances.append((angle, distance))

    lever_mm = math.hypot(C270_DEPTH_WITH_CLIP / 2.0, 6.0 + C270_HEIGHT / 2.0)
    torque_kg_cm = (C270_MASS_G / 1000.0) * (lever_mm / 10.0)
    bb_arm = arm.val().BoundingBox()
    bb_cap = cap.val().BoundingBox()
    bb_cam = camera.val().BoundingBox()
    bb_base = base.val().BoundingBox()

    lines = [
        "C270 ROBOTIC ARM - REVISION G",
        "================================",
        "",
        "Architecture",
        "- Pan axis: Z (vertical), through the 40 mm bottom horn pad.",
        "- Tilt axis: Y (horizontal), at Z = 94 mm.",
        "- Axis relationship: exactly 90 degrees.",
        "- Intended software tilt limit: -45 to +45 degrees.",
        "- Curved-arm edges: exact analytic arcs with a 1 mm edge round; no segmented sketch ridges.",
        "",
        "Input dimensions",
        f"- C270 envelope: {C270_WIDTH:.2f} x {C270_HEIGHT:.2f} x {C270_DEPTH_WITH_CLIP:.2f} mm.",
        f"- C270 mass: {C270_MASS_G:.0f} g.",
        f"- Curved arm: R{ARM_CENTERLINE_RADIUS:.0f}, {ARM_WIDTH:.0f} mm wide, {ARM_THICKNESS:.0f} mm thick, {ARM_CENTER_SPACING:.0f} mm centres.",
        "- Supplied User Library-SG90.sldprt: 32.5 x 30.1 x 12.5 mm exported envelope; mounting-ear slot centres 27.5 mm apart.",
        "",
        "Generated-part bounding boxes (X x Y x Z)",
        f"- Arm/holder: {bb_arm.xlen:.2f} x {bb_arm.ylen:.2f} x {bb_arm.zlen:.2f} mm.",
        f"- Servo cap: {bb_cap.xlen:.2f} x {bb_cap.ylen:.2f} x {bb_cap.zlen:.2f} mm.",
        f"- Screwless camera cradle: {bb_cam.xlen:.2f} x {bb_cam.ylen:.2f} x {bb_cam.zlen:.2f} mm.",
        f"- Nominal C270 body fit clearance: {CRADLE_FIT_CLEARANCE:.2f} mm per side.",
        f"- Cradle right-side cable window: {CRADLE_CABLE_WINDOW_Y:.0f} x {CRADLE_CABLE_WINDOW_Z:.0f} mm.",
        "- Cradle underside: open through the middle for the permanently attached monitor clip.",
        "- Webcam fastening: screwless; corner shelves, side cheeks, rear rail, and flexible top/front corner lips capture the body.",
        f"- Pan-servo stability base: 140.00 x 140.00 x {bb_base.zlen:.2f} mm after STEP re-import.",
        f"- Stability footprint: {BASE_DIAMETER:.0f} mm diameter ({BASE_DIAMETER / 2.0:.0f} mm radius in every pan direction).",
        f"- Pan-servo side ports: two openings, each {BASE_SIDE_PORT_WIDTH:.0f} x {BASE_SIDE_PORT_HEIGHT:.0f} mm, feeding {BASE_SIDE_GROOVE_WIDTH:.0f} mm-wide side grooves.",
        f"- Arm cable routing: two rounded side-entry openings, each {ARM_SIDE_PORT_LENGTH:.0f} x {ARM_SIDE_PORT_HEIGHT:.0f} mm; the back wall remains intact.",
        f"- Pan-servo ear pilots: {SG90_EAR_HOLE_SPACING:.1f} mm centre spacing, {SG90_EAR_PILOT_DIAMETER:.1f} mm pilot diameter for M2 self-tapping screws.",
        f"- Tilt-cap screw pattern: {2 * CAP_SCREW_CENTER_X:.1f} x {2 * CAP_SCREW_CENTER_Z_OFFSET:.1f} mm centres; {CAP_PILOT_DIAMETER:.1f} mm holder pilots and {CAP_CLEARANCE_DIAMETER:.1f} mm cap clearances.",
        f"- Servo-horn interfaces: {HORN_CENTER_CLEARANCE_DIAMETER:.1f} mm centre clearance plus four {HORN_PILOT_DIAMETER:.1f} mm pilots on a {HORN_PILOT_RADIUS:.1f} mm radius.",
        "",
        "Conservative webcam-envelope clearance to the fixed arm/holder",
    ]
    for angle, distance in clearances:
        lines.append(f"- At {angle:+.0f} degrees: {distance:.2f} mm.")
    lines += [
        "",
        f"Static load estimate using a {lever_mm:.1f} mm combined depth/height lever: {torque_kg_cm:.3f} kg-cm.",
        "This excludes acceleration, cable pull, and impact loads.",
        "",
        "Fit and assembly notes",
        "1. Import STEP files into SolidWorks with 3D Interconnect enabled, then save as SLDPRT.",
        "2. Seat the pan SG90 upright on the stability base with its shaft pointing +Z; fasten its ears to the two M2 pilot holes.",
        "3. Point the pan-servo wire toward either gray side tower, pass its plug through the 14 x 9 mm side window, and lay the lead in that side's 14 mm-wide groove.",
        "4. Insert the tilt SG90 from the +Y/front side with its shaft pointing +Y.",
        "5. Secure the cap with four M2 self-tapping screws. Use a thin foam shim if your SG90 clone is loose.",
        "6. Attach the printed screwless cradle to the actual SG90 horn using the adaptable 3.2 mm centre and 2.0 mm pilot-hole pattern. These screws attach only to the horn, never to the webcam.",
        "7. Lower the C270 body into the green basket from above. Let the two corner shelves support its lower edges while the permanently attached monitor clip hangs freely through the open middle underside.",
        "8. Ease the flexible top corner lips over the webcam body. Confirm that the front lens/microphone area is unobstructed and the body cannot slide forward, backward, or sideways.",
        "9. Lead the attached USB cable through the large right-wall relief, then route the bundle through either rounded 16 x 10 mm side window in the blue upper holder. Keep the back wall clear and leave a loose service loop.",
        "10. Set the servo neutral before installing the horn; enforce 45..135 degrees in software for a +/-45 degree tilt range.",
        "11. The four outer base holes can fasten the assembly to a board or accept rubber-foot hardware for additional stability.",
        "12. The included SG90 and C270 reference STEP models are visual proxies; test-fit the physical webcam gently before forcing the flexible lips.",
        "",
        "Printing suggestion",
        "- PETG or PLA+, 0.20 mm layers, 4 perimeters, 35-45% infill.",
        "- Print the 140 mm stability base flat with its circular plate on the bed; keep both tower windows and side grooves clear of support.",
        "- Print the arm on a broad curved side and the cap on its 31 x 24 mm face.",
        "- Print the screwless cradle on one broad outer side wall with a brim; use build-plate-only organic support beneath the horn boss only if Preview shows an unsupported start.",
        "",
        "Package map",
        "- Printable_Parts: four individual STEP/STL printable components, including PanServo_StabilityBase.",
        "- Assemblies: printable assembly and a full visual assembly with two SG90 servos and a C270 proxy.",
        "- Reference_Models: generic SG90 and C270 visualization STEP files.",
        "- Documentation: illustrated build/printing guides, verification report, and this README.",
        "- Renders: neutral assembly, exploded parts, tilt range, pan-base detail, arm side-exit detail, and screwless-cradle detail illustrations.",
        "- Source: parametric CAD generator used to create Revision G.",
        "- Verification_Report.txt: STEP re-import, single-solid, curve, and collision results.",
    ]
    (DOC_DIR / "README_Robotic_Arm_RevG.txt").write_text("\n".join(lines), encoding="utf-8")


def make_previews(
    arm: cq.Workplane,
    cap: cq.Workplane,
    camera: cq.Workplane,
    base: cq.Workplane,
) -> None:
    # VTK is bundled with the CadQuery kernel.  Use off-screen rendering so the
    # user gets a quick visual without changing their live SolidWorks session.
    from vtkmodules.vtkIOGeometry import vtkSTLReader
    from vtkmodules.vtkRenderingCore import (
        vtkActor,
        vtkPolyDataMapper,
        vtkRenderer,
        vtkRenderWindow,
    )
    from vtkmodules.vtkRenderingOpenGL2 import vtkOpenGLRenderer, vtkOpenGLRenderWindow  # noqa: F401
    from vtkmodules.vtkIOImage import vtkPNGWriter
    from vtkmodules.vtkRenderingCore import vtkWindowToImageFilter

    preview_dir = WORK / "preview_revG"
    preview_dir.mkdir(parents=True, exist_ok=True)
    def render_scene(filename, scene, camera_position, focal_point):
        renderer = vtkRenderer()
        renderer.SetBackground(0.965, 0.975, 0.99)
        for index, (name, shape, color, opacity) in enumerate(scene):
            path = preview_dir / f"{filename}_{index}_{name}.stl"
            exporters.export(shape, str(path), tolerance=0.04, angularTolerance=0.05)
            reader = vtkSTLReader()
            reader.SetFileName(str(path))
            mapper = vtkPolyDataMapper()
            mapper.SetInputConnection(reader.GetOutputPort())
            actor = vtkActor()
            actor.SetMapper(mapper)
            actor.GetProperty().SetColor(*color)
            actor.GetProperty().SetOpacity(opacity)
            actor.GetProperty().SetSpecular(0.22)
            actor.GetProperty().SetSpecularPower(20)
            renderer.AddActor(actor)

        window = vtkRenderWindow()
        window.SetOffScreenRendering(1)
        window.SetMultiSamples(8)
        window.SetSize(1400, 1000)
        window.AddRenderer(renderer)
        vtk_camera = renderer.GetActiveCamera()
        vtk_camera.SetPosition(*camera_position)
        vtk_camera.SetFocalPoint(*focal_point)
        vtk_camera.SetViewUp(0, 0, 1)
        renderer.ResetCameraClippingRange()
        window.Render()
        capture = vtkWindowToImageFilter()
        capture.SetInput(window)
        capture.ReadFrontBufferOff()
        capture.Update()
        writer = vtkPNGWriter()
        writer.SetFileName(str(RENDER_DIR / filename))
        writer.SetInputConnection(capture.GetOutputPort())
        writer.Write()

    blue = (0.12, 0.45, 0.86)
    orange = (0.96, 0.55, 0.12)
    green = (0.10, 0.72, 0.49)
    servo_blue = (0.08, 0.24, 0.62)
    white = (0.94, 0.94, 0.90)
    black = (0.06, 0.07, 0.09)
    dark_gray = (0.18, 0.19, 0.22)
    base_gray = (0.26, 0.29, 0.34)
    refs = positioned_reference_models()
    neutral_scene = [
        ("base", base, base_gray, 1.0),
        ("arm", arm, blue, 1.0),
        ("cap", cap, orange, 1.0),
        ("cradle", camera.translate((0, 31.0, TILT_AXIS_Z)), green, 1.0),
        ("pan_servo", refs["SG90_Pan_Body"], servo_blue, 1.0),
        ("pan_horn", refs["SG90_Pan_Horn"], white, 1.0),
        ("tilt_servo", refs["SG90_Tilt_Body"], servo_blue, 1.0),
        ("tilt_horn", refs["SG90_Tilt_Horn"], white, 1.0),
        ("webcam", refs["C270_Webcam_Body"], black, 1.0),
        ("webcam_clip", refs["C270_Fixed_Clip"], dark_gray, 1.0),
    ]
    render_scene(
        "01_Full_Assembly_With_Servos.png",
        neutral_scene,
        (230, -330, 190),
        (0, 14, 42),
    )

    exploded_scene = [
        ("base", base.translate((-65, 35, -12)), base_gray, 1.0),
        ("arm", arm.translate((-50, -28, 18)), blue, 1.0),
        ("cap", cap.translate((25, -10, -55)), orange, 1.0),
        ("cradle", camera.translate((88, 0, 66)), green, 1.0),
    ]
    render_scene(
        "02_Exploded_Printable_Parts.png",
        exploded_scene,
        (265, -365, 210),
        (0, 0, 38),
    )

    webcam_local, clip_local = make_c270_reference()
    moving_local = cq.Compound.makeCompound([camera.val(), webcam_local.val(), clip_local.val()])
    tilt_scene = [
        ("base", base, base_gray, 1.0),
        ("arm", arm, blue, 1.0),
        ("cap", cap, orange, 1.0),
        ("pan_servo", refs["SG90_Pan_Body"], servo_blue, 1.0),
        ("tilt_servo", refs["SG90_Tilt_Body"], servo_blue, 1.0),
    ]
    for label, angle, color, opacity in (
        ("minus45", -45.0, (0.22, 0.67, 0.96), 0.35),
        ("neutral", 0.0, green, 0.82),
        ("plus45", 45.0, (0.63, 0.32, 0.91), 0.35),
    ):
        moved = cq.Workplane(obj=moving_local).rotate((0, 0, 0), (0, 1, 0), angle).translate(
            (0, 31.0, TILT_AXIS_Z)
        )
        tilt_scene.append((label, moved, color, opacity))
    render_scene(
        "03_Tilt_Range_Minus45_to_Plus45.png",
        tilt_scene,
        (235, -345, 175),
        (0, 20, 55),
    )

    base_scene = [
        ("base", base, base_gray, 1.0),
        ("pan_servo", refs["SG90_Pan_Body"], servo_blue, 1.0),
        ("pan_horn", refs["SG90_Pan_Horn"], white, 1.0),
    ]
    render_scene(
        "04_Pan_Servo_Stability_Base.png",
        base_scene,
        (145, -205, 92),
        (0, 0, -9),
    )

    holder_scene = [
        ("arm", arm, blue, 1.0),
        ("tilt_servo", refs["SG90_Tilt_Body"], servo_blue, 0.25),
    ]
    render_scene(
        "05_Arm_Side_Cable_Exit.png",
        holder_scene,
        (180, 120, 112),
        (0, 10, 93),
    )

    webcam_local, clip_local = make_c270_reference()
    cradle_scene = [
        ("cradle", camera, green, 1.0),
        ("webcam", webcam_local, black, 0.82),
        ("fixed_clip", clip_local, dark_gray, 0.45),
    ]
    render_scene(
        "06_Screwless_C270_Cradle.png",
        cradle_scene,
        (120, -175, 88),
        (0, 21, 9),
    )


def main() -> None:
    arm = make_arm_and_holder()
    cap = make_servo_cap()
    camera = make_camera_screwless_cradle()
    base = make_pan_servo_stability_base()
    export_part(arm, "CurvedArm_SG90_TiltHolder")
    export_part(cap, "SG90_RetainingCap")
    export_part(camera, "Logitech_C270_ScrewlessCradle")
    export_part(base, "PanServo_StabilityBase")
    export_reference_models()
    export_positioned_assemblies(arm, cap, camera, base)
    write_report(arm, cap, camera, base)
    make_previews(arm, cap, camera, base)
    print("Generated robotic-arm deliverables in", OUT)


if __name__ == "__main__":
    main()
