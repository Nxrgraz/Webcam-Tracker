"""Build the shareable 3D-printing guide for the C270 Revision H arm."""

from pathlib import Path
import importlib.util

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Pt


ROOT = Path(r"C:\Users\zongs\Documents\Codex\2026-08-20\can-y")
PACKAGE = ROOT / "outputs" / "C270_Robotic_Arm_RevH"
DOC_DIR = PACKAGE / "Documentation"
RENDER_DIR = PACKAGE / "Renders"
OUT = DOC_DIR / "C270_Robotic_Arm_3D_Printing_Guide.docx"


def load_helpers():
    helper_path = ROOT / "work" / "build_documentation_revH.py"
    spec = importlib.util.spec_from_file_location("revg_doc_helpers", helper_path)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


h = load_helpers()


def replace_running_furniture(doc):
    section = doc.sections[0]
    header = section.header.paragraphs[0]
    for run in list(header.runs):
        header._p.remove(run._r)
    h.set_run_font(header.add_run("C270 ROBOTIC ARM"), size=9, color=h.MUTED, bold=True)
    h.set_run_font(header.add_run("\t3D Printing Guide | Revision H"), size=9, color=h.MUTED)

    footer = section.footer.paragraphs[0]
    for run in list(footer.runs):
        footer._p.remove(run._r)
    h.set_run_font(footer.add_run("Shareable maker guide"), size=9, color=h.MUTED)
    h.set_run_font(footer.add_run("\tPage "), size=9, color=h.MUTED)
    h.add_page_number(footer)


def add_checklist(doc, items):
    for item in items:
        h.add_bullet(doc, item)


def build():
    doc = Document()
    h.configure_document(doc)
    replace_running_furniture(doc)

    # Editorial-cover pattern using the compact_reference_guide preset.
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(12)
    p.paragraph_format.space_after = Pt(8)
    h.set_run_font(p.add_run("MAKER PRINT GUIDE"), size=10.5, color=h.GOLD, bold=True)

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(5)
    h.set_run_font(p.add_run("C270 Robotic Arm"), size=30, color=h.NAVY, bold=True)

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(12)
    h.set_run_font(
        p.add_run("How to slice, print, finish, test-fit, and share the four Revision H parts"),
        size=13,
        color=h.MUTED,
    )

    h.add_picture(
        doc,
        RENDER_DIR / "02_Exploded_Printable_Parts.png",
        5.8,
        "Exploded view of the four printable C270 robotic-arm parts: stability base, curved arm and servo holder, retaining cap, and screwless webcam basket cradle.",
        "The four supplied printable components: pan-servo stability base, arm/holder, SG90 cap, and C270 screwless cradle.",
    )

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(2)
    p.paragraph_format.space_after = Pt(4)
    h.set_run_font(p.add_run("Revision H | 28 August 2026"), size=10.5, color=h.GOLD, bold=True)
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    h.set_run_font(
        p.add_run("For common FDM/FFF printers using 1.75 mm PLA+, PETG, or equivalent filament"),
        size=9.5,
        color=h.MUTED,
        italic=True,
    )

    h.page_break(doc)
    h.add_heading(doc, "1. Quick-start recipe", 1)
    h.add_callout(
        doc,
        "START HERE",
        "Import the STL files in millimetres at 100% scale. Use 0.20 mm layers, four walls, 35-45% infill, and a brim for the two taller parts. Print one test part first if your SG90 is a clone or your printer is not dimensionally calibrated.",
        fill=h.LIGHT_BLUE,
    )
    h.add_heading(doc, "Files to print", 2)
    h.add_table(
        doc,
        ["Quantity", "STL file", "What it does"],
        [
            ("1", "PanServo_StabilityBase.stl", "Holds the upright pan SG90 and provides two side-exit cable windows and grooves"),
            ("1", "CurvedArm_SG90_TiltHolder.stl", "Main arm and upper servo cage with two rounded 16 x 10 mm side cable windows"),
            ("1", "SG90_RetainingCap.stl", "Closes the upper servo cage with four M2 screws"),
            ("1", "Logitech_C270_ScrewlessCradle.stl", "Captures the C270 body without screws and connects to the tilt horn"),
        ],
        [1200, 3830, 4330],
    )
    h.add_heading(doc, "Baseline profile", 2)
    h.add_table(
        doc,
        ["Setting", "Recommended start", "Acceptable adjustment"],
        [
            ("Nozzle", "0.4 mm", "0.5-0.6 mm for faster, tougher prints"),
            ("Layer height", "0.20 mm", "0.16 mm for finish; 0.24 mm for speed"),
            ("Walls", "4 perimeters", "Use at least 3; prefer 5 with a larger nozzle"),
            ("Top / bottom", "5 layers each", "Keep at least 1.0 mm total thickness"),
            ("Infill", "35-45% gyroid or cubic", "25% minimum for prototypes"),
            ("Supports", "Build plate only", "Use organic/tree supports where noted"),
            ("Brim", "5-8 mm when needed", "Recommended for the arm and side-laid cradle"),
            ("Base placement", "Circular plate flat on bed", "No support; add a brim only if the rim lifts"),
            ("Scale", "100% in millimetres", "Do not scale only one part"),
        ],
        [1800, 2940, 4620],
    )

    h.page_break(doc)
    h.add_heading(doc, "2. Material and machine setup", 1)
    h.add_heading(doc, "Choose the filament", 2)
    h.add_table(
        doc,
        ["Material", "Use it when", "Notes"],
        [
            ("PLA+", "You want the easiest, stiffest indoor print", "Best first choice. Avoid hot cars, windowsills, and warm enclosures."),
            ("PETG", "You want more impact and heat resistance", "Dry filament first; tune retraction and reduce fan if layer bonding is weak."),
            ("ABS / ASA", "You already print successfully in an enclosure", "Useful for heat resistance, but shrinkage can change servo-pocket fit."),
        ],
        [1500, 3270, 4590],
    )
    h.add_heading(doc, "Before loading the files", 2)
    add_checklist(
        doc,
        [
            "Confirm the build plate is clean, level, and large enough for an 80 mm-long part plus a brim.",
            "Dry PETG or any filament that pops, strings heavily, or has been stored in open air.",
            "Use the filament maker's temperature range; print a temperature tower if this is a new spool.",
            "Verify extrusion flow and first-layer height with a small calibration print.",
            "Measure a known 20 mm calibration object if servo pockets often print too tight or too loose.",
        ],
    )
    h.add_callout(
        doc,
        "SAFETY",
        "Follow the printer and filament manufacturers' instructions. Keep hands away from hot and moving parts, provide ventilation appropriate to the material, and supervise the first layers of every unproven setup.",
        fill=h.LIGHT_GRAY,
    )

    h.page_break(doc)
    h.add_heading(doc, "3. Orient each part", 1)
    h.add_body(
        doc,
        "Use the slicer's Place on Face or Lay Flat command, then inspect every layer in Preview mode. Orientation affects strength, support marks, and hole quality more than infill percentage does.",
    )
    h.add_table(
        doc,
        ["Part", "Bed orientation", "Support and adhesion"],
        [
            ("Pan-servo stability base", "Place the 140 mm plate flat on the bed with the servo towers facing upward.", "No support is normally required. Use a 5-8 mm brim if the rim lifts; keep both 14 x 9 mm side windows, both side grooves, M2 pilots, strap slots, and four counterbores open."),
            ("Curved arm + holder", "Rotate onto one broad smooth curved side so the 6 mm arm profile lies flat.", "Add a 5-8 mm brim. Use build-plate-only organic support beneath unsafe ledges; keep support out of the servo pocket, all screw holes, and both rounded 16 x 10 mm side windows."),
            ("SG90 retaining cap", "Lay the 31 x 24 mm flat face on the bed.", "Normally no support. Block support inside the large circular opening and four M2 holes."),
            ("C270 screwless cradle", "Rotate it onto either broad outer side wall. The basket opening faces sideways and the opposite wall becomes the highest feature.", "Use an 8 mm brim. Add build-plate-only organic support beneath the horn boss only if Preview shows an unsupported start; keep the open underside and wide open-top rear cable notch clear."),
        ],
        [2050, 3260, 4050],
    )
    h.add_picture(
        doc,
        RENDER_DIR / "06_Screwless_C270_Cradle.png",
        4.80,
        "Rear rendering of the C270 body retained by the green screwless basket, with the fixed monitor clip free underneath and the rear USB notch visible.",
        "Before printing, identify the open lens face, open clip underside, flexible top lips, and wide open-top rear USB notch.",
    )
    h.add_callout(
        doc,
        "PREVIEW CHECK",
        "Do not trust automatic support blindly. Scroll through the first 20 layers and every location where a new island begins. No support should fill the SG90 pocket, horn holes, screwless cradle opening, fixed-clip underside gap, or USB-cable relief.",
    )

    h.add_heading(doc, "4. Slice and print", 1)
    steps = [
        "Create a new slicer project and select the correct printer, nozzle, and filament profile.",
        "Import all four STL files. If the slicer asks for units, choose millimetres. Confirm the arm is about 47 x 44 x 104 mm and the base is 140 mm across before reorientation.",
        "Orient the parts using Section 3. Space them far enough apart that one failed part is less likely to damage another.",
        "Apply the baseline profile: 0.20 mm layers, four walls, five top and bottom layers, and 35-45% gyroid or cubic infill.",
        "Add build-plate-only organic supports only where Preview shows unsupported ledges. Add brims to the arm and side-laid cradle; add one to the base only if the outer rim tends to lift.",
        "Slice, then inspect Preview from the first layer to the top. Look for floating islands, blocked holes, missing thin walls, and very short layer times.",
        "Save the project file with the printer, material, nozzle, and revision in its name so another maker can reproduce it.",
        "Start the print and watch the complete first layer. Stop if the brim has gaps, corners lift, or the nozzle drags material.",
        "Let the bed cool before removal. Flex a removable sheet gently; do not pry against the thin arm or the cradle's flexible retaining lips.",
    ]
    num_id = h.new_numbering_instance(doc)
    for step in steps:
        h.add_number(doc, step, num_id)

    h.add_heading(doc, "First-layer acceptance check", 2)
    add_checklist(
        doc,
        [
            "Lines touch without deep ridges or gaps.",
            "The brim is continuous around each enabled part.",
            "No corner has curled upward.",
            "The nozzle does not click, scrape, or collect a blob.",
        ],
    )

    h.page_break(doc)
    h.add_heading(doc, "5. Clean and test-fit", 1)
    h.add_heading(doc, "Remove support carefully", 2)
    h.add_body(
        doc,
        "Use flush cutters and a deburring tool rather than twisting supports off the cradle's flexible corner lips. Preserve the gray base windows and grooves, both blue upper-holder side windows, the green open underside, the green open-top rear cable notch, four cap screw bosses, and every mounting hole. Do not open a route through the blue back wall.",
    )
    h.add_heading(doc, "Check the critical fits", 2)
    h.add_table(
        doc,
        ["Feature", "Correct result", "If it is wrong"],
        [
            ("Pan-base SG90 mount", "Supplied servo ear slots align with the two 1.9 mm pilots on 27.5 mm centres", "Verify orientation and cable routing. If a clone differs, use the backup strap slots rather than forcing the screws."),
            ("Upper SG90 pocket", "Servo slides in firmly without forcing or rocking", "Sand high spots lightly. If consistently tight, tune XY/hole compensation before scaling the model."),
            ("Retaining cap", "Cap seats flat and the output tower clears the round opening", "Remove strings; check cap orientation; do not enlarge the opening until the real servo is compared."),
            ("M2 cap pattern", "Four 1.8 mm blue pilots align with four 2.4 mm orange clearances on 27.7 x 15.0 mm centres", "Clear holes by hand only; never power-drive into thin plastic or enlarge the orange holes unevenly."),
            ("Servo horn pattern", "Center screw and at least two pilot holes can be used", "Use the supplied horn as a drilling template; SG90 horn patterns vary."),
            ("C270 screwless cradle", "Body rests on both corner shelves; fixed clip hangs through the open underside; top lips retain the body", "Remove support first. If the body is slightly loose, add a thin foam strip to a side or rear wall; never force or screw into the webcam."),
        ],
        [2040, 3280, 4040],
    )
    h.add_callout(
        doc,
        "DO NOT SCALE FOR ONE BAD FIT",
        "Uniform scaling changes the 140 mm base, 80 mm arm spacing, servo mounts, horn holes, and webcam interface together. Correct printer calibration or use slicer XY/hole compensation first. Edit the STEP model only when a measured hardware difference is confirmed.",
        fill=h.LIGHT_BLUE,
    )

    h.page_break(doc)
    h.add_heading(doc, "6. Assemble the printed parts", 1)
    h.add_picture(
        doc,
        RENDER_DIR / "01_Full_Assembly_With_Servos.png",
        3.10,
        "Complete Revision H pan-tilt assembly with a gray circular side-routing base, a blue upper holder with side-only cable exits, two SG90 visual-reference servos, retaining cap, and rear-notched screwless webcam basket.",
        "Completed arrangement: vertical pan servo on the gray base, horizontal tilt servo above, and the C270 body captured by the green screwless cradle.",
    )
    steps = [
        "Center both SG90 servos electrically before installing either horn.",
        "Place the gray base flat. Orient the pan SG90 wire toward either side tower, pass its plug through that tower's 14 x 9 mm window, lay the lead in the matching 14 mm-wide groove, then seat the servo upright.",
        "Fasten both pan-servo ears with M2 screws through the supplied servo's 27.5 mm-centre slots into the two 1.9 mm base pilots. If a clone differs, use a narrow zip tie through the backup slots.",
        "Attach the blue lower pan pad to the horn on the vertical pan servo.",
        "Slide the second SG90 into the upper cage with its shaft horizontal and pointing toward the camera side.",
        "Install the orange cap with four M2 screws through its 2.4 mm clearances into the blue 1.8 mm pilots. The centres are 27.7 x 15.0 mm; tighten only until the servo cannot shift.",
        "Fasten the green screwless cradle to the centered tilt horn using the center screw and matching pilot holes. The screw attaches only to the horn, never to the webcam.",
        "Lower the C270 body into the basket from above. Let its lower edges rest on the two corner shelves while the permanent monitor clip hangs through the open centre underside.",
        "Ease the flexible top corner lips over the body. Confirm that the lens face is open and the camera cannot slide forward, backward, or sideways.",
        "Let the USB lead leave through the 52 mm-wide rear notch, bend around either green side, then pass both upper leads through either blue 16 x 10 mm side window. Keep the blue back wall intact and leave separate tilt and pan loops.",
    ]
    num_id = h.new_numbering_instance(doc)
    for step in steps:
        h.add_number(doc, step, num_id)
    h.add_callout(
        doc,
        "FIRST POWER TEST",
        "Command neutral first, then move in small steps. Begin with tilt limits of 45-135 degrees for the intended +/-45 degree range. Stop immediately if the cable tightens, a servo stalls, or the printed holder flexes visibly.",
    )

    h.page_break(doc)
    h.add_heading(doc, "7. Troubleshooting and sharing", 1)
    h.add_heading(doc, "Common print problems", 2)
    h.add_table(
        doc,
        ["Symptom", "Likely cause", "Try this next"],
        [
            ("Base or arm edge lifts", "Poor first layer or cooling draft", "Clean and level the bed, add an 8 mm brim, reduce first-layer speed, and avoid drafts."),
            ("Servo pocket too tight", "Over-extrusion or XY growth", "Verify flow, elephant-foot compensation, and XY size; sand only small high spots."),
            ("Cap screw splits plastic", "Hole too small or screw overtightened", "Open the pilot hole by hand and stop tightening when the cap seats."),
            ("Camera loose in cradle", "Body is smaller than the supplied envelope or support remains", "Remove support and check shelf seating; add a thin foam strip to one side or rear wall if needed."),
            ("Top lip will not pass body", "Elephant foot, over-extrusion, or insufficient flex", "Deburr only the lip underside, warm PETG slightly by hand, and never force the webcam or drill into it."),
            ("Layers split near holder", "Low temperature, weak cooling setup, or too few walls", "Increase nozzle temperature within the filament range, reduce excessive cooling, and use four walls."),
        ],
        [2330, 2780, 4250],
    )
    h.add_heading(doc, "Information to share with another maker", 2)
    add_checklist(
        doc,
        [
            "Design name and revision: C270 Robotic Arm, Revision H.",
            "Printer model, nozzle size, filament brand/type, and whether the filament was dried.",
            "Layer height, walls, infill, supports, brim, orientation, and any XY/hole compensation or edited dimensions.",
            "Photos of the first layer, completed parts, and critical SG90/C270 fits.",
            "A note that the included SG90 and C270 STEP references are visual proxies and physical hardware should be test-fitted.",
        ],
    )
    h.add_heading(doc, "Final handoff checklist", 2)
    add_checklist(
        doc,
        [
            "All four STL files are included; the green Logitech_C270_ScrewlessCradle.stl is the only changed printable part from Revision G.",
            "Both guides are included, and the slicer project identifies the exact printer and material profile.",
            "Recipients re-slice for their own printer rather than treating machine code as universal.",
            "Before tracking is enabled, check the base side exits, both blue 16 x 10 mm windows, the green rear cable notch, the open fixed-clip underside, and every screw hole.",
        ],
    )
    doc.core_properties.title = "C270 Robotic Arm - 3D Printing Guide"
    doc.core_properties.subject = "Revision H slicing, FDM printing, screwless C270 cradle, rear webcam-cable relief, side-only arm cable routing, and sharing instructions"
    doc.core_properties.author = "Codex"
    doc.core_properties.keywords = "Logitech C270, SG90, 3D printing, FDM, STL, robotic arm"
    doc.core_properties.comments = "Generated for the validated C270 Robotic Arm Revision H package with a rear-notched screwless webcam cradle and verified clearances."

    DOC_DIR.mkdir(parents=True, exist_ok=True)
    doc.save(OUT)
    print(OUT)


if __name__ == "__main__":
    build()
