from collections import Counter
from pathlib import Path
import importlib.util

import cadquery as cq


ROOT = Path(r"C:\Users\zongs\Documents\Codex\2026-08-20\can-y")
OUT = ROOT / "outputs" / "C270_Robotic_Arm_RevL"


def load_generator():
    path = ROOT / "work" / "generate_robotic_arm_revL.py"
    spec = importlib.util.spec_from_file_location("arm_revl", path)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


print("STEP RE-IMPORT CHECK")
step_counts = {}
for path in sorted(OUT.rglob("*.step")):
    shape = cq.importers.importStep(str(path))
    solids = shape.solids().vals()
    valid = all(s.isValid() for s in solids)
    relative = str(path.relative_to(OUT)).replace("\\", "/")
    step_counts[relative] = len(solids)
    print(f"{relative} | solids={len(solids)} | valid={valid}")

g = load_generator()
arm = g.make_arm_and_holder()
cap = g.make_servo_cap()
base = g.make_pan_servo_stability_base()
camera = g.make_camera_screwless_cradle()
refs = g.positioned_reference_models()
webcam_local, webcam_clip_local = g.make_c270_reference()

edge_types = Counter(edge.geomType() for edge in arm.edges().vals())
print("\nARM EDGE TYPES", dict(edge_types))
print("Arm exact-circle edges:", edge_types.get("CIRCLE", 0))
print("Arm spline edges:", edge_types.get("BSPLINE", 0))


def intersection_volume(a, b):
    result = a.intersect(b)
    return sum(s.Volume() for s in result.solids().vals())


checks = {
    "pan servo body vs arm": intersection_volume(refs["SG90_Pan_Body"], arm),
    "pan horn vs arm": intersection_volume(refs["SG90_Pan_Horn"], arm),
    "pan servo body vs stability base": intersection_volume(refs["SG90_Pan_Body"], base),
    "pan horn vs stability base": intersection_volume(refs["SG90_Pan_Horn"], base),
    "stability base vs arm": intersection_volume(base, arm),
    "tilt servo body vs arm": intersection_volume(refs["SG90_Tilt_Body"], arm),
    "tilt servo body vs cap": intersection_volume(refs["SG90_Tilt_Body"], cap),
    "tilt horn vs cap": intersection_volume(refs["SG90_Tilt_Horn"], cap),
    "C270 body vs screwless cradle": intersection_volume(webcam_local, camera),
    "C270 fixed clip vs screwless cradle": intersection_volume(webcam_clip_local, camera),
}
print("\nREFERENCE COLLISION CHECK (mm^3)")
for name, volume in checks.items():
    print(f"{name}: {volume:.4f}")

base_bb = base.val().BoundingBox()
print("\nSTABILITY BASE")
print(f"Bounding box: {base_bb.xlen:.2f} x {base_bb.ylen:.2f} x {base_bb.zlen:.2f} mm")
print(f"Volume: {base.val().Volume():.2f} mm^3")
if abs(base_bb.xlen - g.BASE_DIAMETER) > 0.05 or abs(base_bb.ylen - g.BASE_DIAMETER) > 0.05:
    raise SystemExit("VERIFY FAILED: stability-base footprint is not the specified diameter")

camera_bb = camera.val().BoundingBox()
cap_bb = cap.val().BoundingBox()
print("\nSCREWLESS C270 CRADLE")
print(f"Bounding box: {camera_bb.xlen:.2f} x {camera_bb.ylen:.2f} x {camera_bb.zlen:.2f} mm")
print(f"Nominal body clearance per side: {g.CRADLE_FIT_CLEARANCE:.2f} mm")
print(f"Open inside width: {2.0 * g.CRADLE_INNER_HALF_X:.2f} mm")
print(f"Central rear cable opening: {g.CRADLE_REAR_KEEPER_GAP_WIDTH:.2f} mm wide")
print(f"Rear corner barrier height: {g.CRADLE_REAR_KEEPER_HEIGHT:.2f} mm")
print(f"Nominal flexible side-grip preload: {g.CRADLE_SIDE_GRIP_PRELOAD:.2f} mm per side")

print("\nENLARGED SG90 RETAINING CAP")
print(f"Bounding box: {cap_bb.xlen:.2f} x {cap_bb.ylen:.2f} x {cap_bb.zlen:.2f} mm")
print(
    f"Output-tower rectangle: {g.CAP_OUTPUT_OPENING_LENGTH:.2f} x "
    f"{g.CAP_OUTPUT_OPENING_HEIGHT:.2f} mm"
)
cap_head_edge_margin = (
    g.CAP_WIDTH / 2.0
    - g.CAP_SCREW_CENTER_X
    - g.CAP_SCREW_HEAD_PROXY_DIAMETER / 2.0
)
print(f"Outer edge beyond a 4 mm M2 head proxy: {cap_head_edge_margin:.2f} mm")

# Confirm both pan-servo side windows, both plate grooves, and both upper-holder
# side windows are unobstructed.  Each probe stays inside its design limits.
left_port_probe = g.box_at(-19.4, -11.6, -6.9, 6.9, -19.9, -11.1)
right_port_probe = g.box_at(11.6, 19.4, -6.9, 6.9, -19.9, -11.1)
left_groove_probe = g.box_at(-69.0, -18.5, -6.9, 6.9, -24.9, -21.0)
right_groove_probe = g.box_at(18.5, 69.0, -6.9, 6.9, -24.9, -21.0)
left_arm_port_probe = g.side_capsule_x(
    -17.4,
    -11.6,
    g.ARM_SIDE_PORT_CENTER_Y,
    g.ARM_SIDE_PORT_LENGTH - 0.4,
    g.ARM_SIDE_PORT_HEIGHT - 0.4,
    g.TILT_AXIS_Z,
)
right_arm_port_probe = g.side_capsule_x(
    11.6,
    17.4,
    g.ARM_SIDE_PORT_CENTER_Y,
    g.ARM_SIDE_PORT_LENGTH - 0.4,
    g.ARM_SIDE_PORT_HEIGHT - 0.4,
    g.TILT_AXIS_Z,
)
wiring_blockages = {
    "left pan-servo side port": intersection_volume(base, left_port_probe),
    "right pan-servo side port": intersection_volume(base, right_port_probe),
    "left base cable groove": intersection_volume(base, left_groove_probe),
    "right base cable groove": intersection_volume(base, right_groove_probe),
    "left arm-holder side port": intersection_volume(arm, left_arm_port_probe),
    "right arm-holder side port": intersection_volume(arm, right_arm_port_probe),
}
cradle_cable_probe = g.box_at(
    -g.CRADLE_REAR_KEEPER_INNER_X + 0.2,
    g.CRADLE_REAR_KEEPER_INNER_X - 0.2,
    g.CRADLE_BACK_Y - 0.25,
    g.CRADLE_BACK_Y + g.CRADLE_WALL + 0.4,
    g.CRADLE_BOTTOM_Z - g.CRADLE_WALL + 0.2,
    g.CRADLE_TOP_Z + g.CRADLE_WALL - 0.2,
)
wiring_blockages["screwless cradle 62 mm center cable opening"] = intersection_volume(
    camera, cradle_cable_probe
)

keeper_probe_left = g.box_at(
    -g.CRADLE_OUTER_HALF_X + 0.1,
    -g.CRADLE_REAR_KEEPER_INNER_X - 0.1,
    g.CRADLE_BACK_Y + 0.1,
    g.CRADLE_BACK_Y + g.CRADLE_WALL - 0.1,
    g.CRADLE_BOTTOM_Z + 0.1,
    g.CRADLE_BOTTOM_Z + g.CRADLE_REAR_KEEPER_HEIGHT - 0.1,
)
keeper_probe_right = g.box_at(
    g.CRADLE_REAR_KEEPER_INNER_X + 0.1,
    g.CRADLE_OUTER_HALF_X - 0.1,
    g.CRADLE_BACK_Y + 0.1,
    g.CRADLE_BACK_Y + g.CRADLE_WALL - 0.1,
    g.CRADLE_BOTTOM_Z + 0.1,
    g.CRADLE_BOTTOM_Z + g.CRADLE_REAR_KEEPER_HEIGHT - 0.1,
)
keeper_presence = {
    "left rear corner barrier": intersection_volume(camera, keeper_probe_left),
    "right rear corner barrier": intersection_volume(camera, keeper_probe_right),
}
print("\nREAR RETENTION BARRIER CHECK (mm^3 material present)")
for name, volume in keeper_presence.items():
    print(f"{name}: {volume:.4f}")
print("\nWIRING ROUTE CHECK (mm^3 blockage)")
for name, volume in wiring_blockages.items():
    print(f"{name}: {volume:.4f}")

# Verify every documented printed screw hole is open and the centre distances
# match the supplied SG90 ear-slot geometry or the stated printed-part pattern.
screw_hole_blockages = {}
for x in (-g.SG90_EAR_HOLE_SPACING / 2.0, g.SG90_EAR_HOLE_SPACING / 2.0):
    probe = g.cyl_z(g.SG90_EAR_PILOT_DIAMETER / 2.0 - 0.08, -15.0, -7.8, x, 0.0)
    screw_hole_blockages[f"base M2 pilot at X={x:.2f}"] = intersection_volume(base, probe)
for x in (-g.CAP_SCREW_CENTER_X, g.CAP_SCREW_CENTER_X):
    for z in (g.TILT_AXIS_Z - g.CAP_SCREW_CENTER_Z_OFFSET, g.TILT_AXIS_Z + g.CAP_SCREW_CENTER_Z_OFFSET):
        holder_probe = g.cyl_y(g.CAP_PILOT_DIAMETER / 2.0 - 0.08, 1.6, 24.4, x, z)
        cap_probe = g.cyl_y(g.CAP_CLEARANCE_DIAMETER / 2.0 - 0.08, 23.6, 27.4, x, z)
        screw_hole_blockages[f"holder M2 pilot X={x:.2f} Z={z:.2f}"] = intersection_volume(arm, holder_probe)
        screw_hole_blockages[f"cap M2 clearance X={x:.2f} Z={z:.2f}"] = intersection_volume(cap, cap_probe)

pad_center_probe = g.cyl_z(g.HORN_CENTER_CLEARANCE_DIAMETER / 2.0 - 0.08, 3.6, 8.4)
screw_hole_blockages["pan horn centre clearance"] = intersection_volume(arm, pad_center_probe)
cradle_center_probe = g.cyl_y(g.HORN_CENTER_CLEARANCE_DIAMETER / 2.0 - 0.08, -0.4, 9.4, 0.0, 0.0)
screw_hole_blockages["tilt horn centre clearance"] = intersection_volume(camera, cradle_center_probe)

opening_radius = g.CAP_OUTPUT_OPENING_HEIGHT / 2.0 - 0.10
opening_half_span = g.CAP_OUTPUT_OPENING_LENGTH / 2.0 - 0.10
cap_output_probe = g.box_at(
    -opening_half_span,
    opening_half_span,
    24.05,
    26.95,
    g.TILT_AXIS_Z - opening_radius,
    g.TILT_AXIS_Z + opening_radius,
)
screw_hole_blockages["tilt-cap 22 x 15 mm output rectangle"] = intersection_volume(
    cap, cap_output_probe.clean()
)
for x, y in (
    (g.HORN_PILOT_RADIUS, 0.0),
    (-g.HORN_PILOT_RADIUS, 0.0),
    (0.0, g.HORN_PILOT_RADIUS),
    (0.0, -g.HORN_PILOT_RADIUS),
):
    probe = g.cyl_z(g.HORN_PILOT_DIAMETER / 2.0 - 0.08, 3.6, 8.4, x, y)
    screw_hole_blockages[f"pan horn pilot X={x:.1f} Y={y:.1f}"] = intersection_volume(arm, probe)
for x, z in (
    (g.HORN_PILOT_RADIUS, 0.0),
    (-g.HORN_PILOT_RADIUS, 0.0),
    (0.0, g.HORN_PILOT_RADIUS),
    (0.0, -g.HORN_PILOT_RADIUS),
):
    probe = g.cyl_y(g.HORN_PILOT_DIAMETER / 2.0 - 0.08, -0.4, 9.4, x, z)
    screw_hole_blockages[f"tilt horn pilot X={x:.1f} Z={z:.1f}"] = intersection_volume(camera, probe)

print("\nSCREW PATTERN CHECK")
print(f"Supplied SG90 ear-slot centre spacing: {g.SG90_EAR_HOLE_SPACING:.2f} mm")
print(f"Base M2 pilot diameter: {g.SG90_EAR_PILOT_DIAMETER:.2f} mm")
print(f"Cap screw centre pattern: {2 * g.CAP_SCREW_CENTER_X:.2f} x {2 * g.CAP_SCREW_CENTER_Z_OFFSET:.2f} mm")
print(f"Holder/cap diameters: {g.CAP_PILOT_DIAMETER:.2f} / {g.CAP_CLEARANCE_DIAMETER:.2f} mm")
for name, volume in screw_hole_blockages.items():
    print(f"{name}: {volume:.4f} mm^3 blockage")

failed = []
expected_counts = {
    "Printable_Parts/CurvedArm_SG90_TiltHolder.step": 1,
    "Printable_Parts/SG90_RetainingCap.step": 1,
    "Printable_Parts/Logitech_C270_ScrewlessCradle.step": 1,
    "Printable_Parts/PanServo_StabilityBase.step": 1,
    "Assemblies/C270_PanTilt_Printable_Assembly.step": 4,
    "Assemblies/C270_PanTilt_Full_Assembly_With_Servos.step": 10,
    "Reference_Models/SG90_Visual_Reference.step": 2,
    "Reference_Models/Logitech_C270_Visual_Reference.step": 2,
}
for relative, expected in expected_counts.items():
    actual = step_counts.get(relative)
    if actual != expected:
        failed.append(f"{relative}: expected {expected} solids, found {actual}")
for path in sorted(OUT.rglob("*.step")):
    shape = cq.importers.importStep(str(path))
    if not all(s.isValid() for s in shape.solids().vals()):
        failed.append(str(path))
for name, volume in checks.items():
    if name == "C270 body vs screwless cradle":
        # The two small flexible side ribs intentionally preload the nominal
        # webcam envelope.  All other reference collisions must remain zero.
        if volume < 0.10 or volume > 20.0:
            failed.append(f"unexpected side-grip preload volume={volume:.4f} mm^3")
    elif volume > 0.10:
        failed.append(f"{name}={volume:.4f} mm^3")
for name, volume in wiring_blockages.items():
    if volume > 0.10:
        failed.append(f"{name} blockage={volume:.4f} mm^3")
for name, volume in screw_hole_blockages.items():
    if volume > 0.10:
        failed.append(f"{name} blockage={volume:.4f} mm^3")
if abs(g.SG90_EAR_HOLE_SPACING - 27.5) > 0.001:
    failed.append("base SG90 ear-hole spacing is not 27.5 mm")
if abs(2.0 * g.CRADLE_INNER_HALF_X - (g.C270_WIDTH + 2.0 * g.CRADLE_FIT_CLEARANCE)) > 0.001:
    failed.append("screwless cradle width allowance is inconsistent")
if abs(g.CRADLE_REAR_KEEPER_GAP_WIDTH - 62.0) > 0.001:
    failed.append("central rear cable opening is not 62 mm wide")
if abs(g.CRADLE_REAR_KEEPER_HEIGHT - 8.0) > 0.001:
    failed.append("rear corner barrier height is not 8 mm")
if abs(cap_bb.xlen - g.CAP_WIDTH) > 0.05 or abs(cap_bb.zlen - g.CAP_HEIGHT) > 0.05:
    failed.append("enlarged retaining-cap outer dimensions are incorrect")
if abs(g.CAP_OUTPUT_OPENING_LENGTH - 22.0) > 0.001:
    failed.append("retaining-cap output opening length is not 22 mm")
if abs(g.CAP_OUTPUT_OPENING_HEIGHT - 15.0) > 0.001:
    failed.append("retaining-cap output opening height is not 15 mm")
if cap_head_edge_margin < 2.0:
    failed.append("retaining-cap outer edge is too close to a 4 mm M2 screw head")
web = g.CAP_SCREW_CENTER_X - g.CAP_OUTPUT_OPENING_LENGTH / 2 - g.CAP_CLEARANCE_DIAMETER / 2
print(f"Minimum opening-to-screw-hole material: {web:.2f} mm")
if web < 1.6:
    failed.append("rectangle leaves insufficient material beside screw holes")
# All inner opening edges must be straight, not arcs or splines.
inner_edges = [e for e in cap.edges().vals()
               if abs(e.Center().x) <= g.CAP_OUTPUT_OPENING_LENGTH / 2 + 0.001
               and abs(e.Center().z - g.TILT_AXIS_Z) <= g.CAP_OUTPUT_OPENING_HEIGHT / 2 + 0.001]
if not inner_edges or any(e.geomType() != "LINE" for e in inner_edges):
    failed.append("output opening is not entirely straight-sided")
for name, volume in keeper_presence.items():
    if volume < 1.0:
        failed.append(f"{name} is missing; material volume={volume:.4f} mm^3")
if failed:
    raise SystemExit("VERIFY FAILED: " + "; ".join(failed))
print("\nVERIFY PASSED")
