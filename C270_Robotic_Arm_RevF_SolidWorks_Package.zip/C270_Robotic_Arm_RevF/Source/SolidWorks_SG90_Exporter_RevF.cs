using System;
using SolidWorks.Interop.sldworks;
using SolidWorks.Interop.swconst;

internal static class ExportSg90
{
    public static int Main(string[] args)
    {
        string input = @"C:\Users\zongs\Downloads\User Library-SG90\User Library-SG90.sldprt";
        string output = @"C:\Users\zongs\Documents\Codex\2026-08-20\can-y\work\User_Library_SG90.step";
        int openErrors = 0;
        int openWarnings = 0;
        int saveErrors = 0;
        int saveWarnings = 0;
        SldWorks sw = null;
        ModelDoc2 model = null;

        try
        {
            sw = new SldWorks();
            model = sw.OpenDoc6(
                input,
                (int)swDocumentTypes_e.swDocPART,
                (int)swOpenDocOptions_e.swOpenDocOptions_Silent,
                "",
                ref openErrors,
                ref openWarnings);

            if (model == null)
            {
                Console.Error.WriteLine("OPEN_FAILED errors={0} warnings={1}", openErrors, openWarnings);
                return 2;
            }

            PartDoc part = (PartDoc)model;
            object rawBox = part.GetPartBox(true);
            double[] box = rawBox as double[];
            if (box != null && box.Length >= 6)
            {
                Console.WriteLine(
                    "SOLIDWORKS_PART_BOX_MM={0:F3},{1:F3},{2:F3}",
                    Math.Abs((box[3] - box[0]) * 1000.0),
                    Math.Abs((box[4] - box[1]) * 1000.0),
                    Math.Abs((box[5] - box[2]) * 1000.0));
            }

            bool ok = model.Extension.SaveAs(
                output,
                (int)swSaveAsVersion_e.swSaveAsCurrentVersion,
                (int)swSaveAsOptions_e.swSaveAsOptions_Silent,
                null,
                ref saveErrors,
                ref saveWarnings);
            if (!ok)
            {
                Console.Error.WriteLine("SAVE_FAILED errors={0} warnings={1}", saveErrors, saveWarnings);
                return 3;
            }
            Console.WriteLine("STEP_EXPORTED={0}", output);
            return 0;
        }
        catch (Exception ex)
        {
            Console.Error.WriteLine(ex.ToString());
            return 4;
        }
        finally
        {
            if (model != null && sw != null)
            {
                sw.CloseDoc(model.GetTitle());
            }
            if (sw != null)
            {
                sw.ExitApp();
            }
        }
    }
}
