from collections import defaultdict
from pathlib import Path

import cadquery as cq


path = Path(r"C:\Users\zongs\Documents\Codex\2026-08-20\can-y\work\User_Library_SG90.step")
model = cq.importers.importStep(str(path))
solids = model.solids().vals()
print(f"SOLIDS={len(solids)} VALID={all(s.isValid() for s in solids)}")
bb = model.val().BoundingBox()
print(f"BBOX_MM={bb.xlen:.3f},{bb.ylen:.3f},{bb.zlen:.3f}")

circles = []
for edge in model.edges().vals():
    if edge.geomType() != "CIRCLE":
        continue
    center = edge.Center()
    try:
        radius = edge.radius()
    except Exception:
        radius = 0.0
    try:
        arc_center = edge.arcCenter()
        ac = (arc_center.x, arc_center.y, arc_center.z)
    except Exception:
        ac = (center.x, center.y, center.z)
    circles.append((radius, center.x, center.y, center.z, ac[0], ac[1], ac[2]))

groups = defaultdict(list)
for radius, x, y, z, acx, acy, acz in circles:
    groups[round(radius, 3)].append((round(acx, 3), round(acy, 3), round(acz, 3)))

print("CIRCULAR_EDGE_GROUPS")
for radius in sorted(groups):
    if radius > 1.5:
        continue
    unique = sorted(set(groups[radius]))
    print(f"R={radius:.3f} COUNT={len(groups[radius])} UNIQUE_CENTERS={unique}")
